# C++ Memory Issue - Entity Component System

An Entity Component System demonstrating common C++ memory management bugs.

## Difficulty: ⭐⭐⭐⭐⭐

## Bug Categories

### Memory Leaks
- `Sprite` class has no destructor - `textureData` leaked
- `DynamicArray::resize()` doesn't delete old array
- `removeChild()` removes but doesn't delete
- `Script::setUserData()` overwrites without freeing old data
- Singleton instance never deleted
- `clearWrong()` clears map without deleting entities

### Dangling Pointers
- `getComponent()` returns raw pointer that gets deleted
- `parent` pointer can reference destroyed entity
- Iterators invalidated during modification
- References to removed components

### Double Free
- `shallowClone()` creates entity sharing component pointers
- `MyString` shallow copy - both delete same buffer
- Parent/child destruction with shared entities
- Reference count going negative

### Use After Free
- Component accessed after `removeComponent()`
- Entity accessed after `destroyEntity()`
- Buffer used after `delete[]`

### Shallow vs Deep Copy
- Default copy constructor does shallow copy
- `clone()` methods inconsistent
- Rule of Three/Five violations
- `void*` pointer copying

### Buffer Overflows
- `DynamicArray::operator[]` no bounds checking
- `pop()` doesn't check for empty array
- String operations without length checks

### Reference Counting Bugs
- `release()` doesn't guard against over-release
- No atomic operations for thread safety
- Negative reference count possible

### Circular References
- Parent/child relationships create cycles
- `deepClone()` infinite recursion on cycles
- Can't safely delete cyclic structures

## Expected Behavior

### What Should Happen
- All allocated memory is freed
- Pointers are valid when used
- Copies are independent
- Reference counts are accurate

### What Actually Happens
```
==12345== LEAK SUMMARY:
==12345==    definitely lost: 262,144 bytes in 1 blocks
==12345==    indirectly lost: 0 bytes in 0 blocks

AddressSanitizer: heap-use-after-free
AddressSanitizer: double-free
AddressSanitizer: heap-buffer-overflow
```

## Build & Run

```bash
mkdir build && cd build
cmake -DENABLE_ASAN=ON ..
make
./MemoryDemo

# Or with Valgrind:
cmake -DENABLE_DEBUG=ON ..
make
valgrind --leak-check=full ./MemoryDemo
```

## Memory Bug Summary

| Bug Type | Location | Symptom |
|----------|----------|---------|
| Leak | `Sprite` | Valgrind reports lost bytes |
| Dangling | `getComponent` | Crash/corruption on access |
| Double Free | `shallowClone` | SIGABRT/crash |
| Use After Free | `removeComponent` | Undefined behavior |
| Overflow | `operator[]` | Memory corruption |
| Shallow Copy | `MyString` | Double free on destroy |

## Key Files to Examine

1. **include/EntitySystem.h** - All classes with memory bugs
   - `Sprite` - Missing destructor
   - `Entity` - Raw pointer management
   - `EntityManager` - Singleton leak
   - `DynamicArray` - Rule of Three violation
   - `MyString` - Shallow copy issues
   - `Texture` - Reference counting bugs

2. **src/main.cpp** - Demonstrations of each bug type

## Project Structure

```
memory_issue/
├── CMakeLists.txt
├── include/
│   └── EntitySystem.h    # Classes with memory bugs
├── src/
│   └── main.cpp          # Bug demonstrations
└── README.md
```

## Correct Patterns (Reference)

```cpp
// Rule of Five
class SafeArray {
    int* data;
    size_t size;
public:
    ~SafeArray() { delete[] data; }
    SafeArray(const SafeArray& other);            // Deep copy
    SafeArray(SafeArray&& other) noexcept;        // Move
    SafeArray& operator=(const SafeArray& other); // Copy assign
    SafeArray& operator=(SafeArray&& other) noexcept; // Move assign
};

// Smart pointers
std::unique_ptr<Component> component;
std::shared_ptr<Entity> entity;
std::weak_ptr<Entity> parent;

// RAII resource management
class Texture {
    std::unique_ptr<unsigned char[]> data;
};
```

## Detection Tools

1. **Valgrind** - Memory leak detection
2. **AddressSanitizer** - Use-after-free, buffer overflow
3. **LeakSanitizer** - Memory leak detection
4. **UndefinedBehaviorSanitizer** - Undefined behavior detection
