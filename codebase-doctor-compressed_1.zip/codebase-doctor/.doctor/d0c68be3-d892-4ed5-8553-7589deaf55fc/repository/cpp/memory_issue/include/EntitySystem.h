#ifndef ENTITY_SYSTEM_H
#define ENTITY_SYSTEM_H

#include <string>
#include <vector>
#include <map>
#include <memory>

namespace ECS {

// =============================================================================
// Entity Component System with Memory Management Bugs
// =============================================================================

class Component {
public:
    virtual ~Component() = default;
    virtual void update(float dt) = 0;
    virtual Component* clone() const = 0;
    
    std::string name;
};

class Transform : public Component {
public:
    float x, y, z;
    float rotX, rotY, rotZ;
    float scaleX, scaleY, scaleZ;
    
    Transform() : x(0), y(0), z(0), rotX(0), rotY(0), rotZ(0),
                  scaleX(1), scaleY(1), scaleZ(1) {
        name = "Transform";
    }
    
    void update(float dt) override { }
    
    Component* clone() const override {
        return new Transform(*this);
    }
};

class Sprite : public Component {
public:
    // BUG: Raw pointer to dynamically allocated texture data
    unsigned char* textureData;
    int width, height;
    
    Sprite(int w, int h) : width(w), height(h) {
        name = "Sprite";
        textureData = new unsigned char[w * h * 4];  // RGBA
    }
    
    // BUG: No destructor - memory leak
    // ~Sprite() { delete[] textureData; }  // Missing!
    
    void update(float dt) override { }
    
    // BUG: Shallow copy - both objects share textureData pointer
    Component* clone() const override {
        return new Sprite(*this);  // Uses default copy constructor
    }
};

class Script : public Component {
public:
    // BUG: Raw pointer without ownership clarity
    void* userData;
    
    Script() : userData(nullptr) {
        name = "Script";
    }
    
    void setUserData(void* data) {
        // BUG: No cleanup of old userData
        userData = data;  // Previous data leaked
    }
    
    void update(float dt) override { }
    
    Component* clone() const override {
        Script* copy = new Script();
        // BUG: Shallow copy of void pointer
        copy->userData = userData;  // Both point to same memory
        return copy;
    }
};

// =============================================================================
// Entity class with memory issues
// =============================================================================

class Entity {
public:
    std::string name;
    
    // BUG: Raw pointers in vector - ownership unclear
    std::vector<Component*> components;
    
    // BUG: Raw pointer to parent - can become dangling
    Entity* parent;
    
    // BUG: Raw pointers to children
    std::vector<Entity*> children;
    
    Entity(const std::string& name) : name(name), parent(nullptr) { }
    
    // BUG: Destructor doesn't clean up children or components properly
    ~Entity() {
        // BUG: Children are deleted but might be referenced elsewhere
        for (auto* child : children) {
            delete child;  // What if child is also in another container?
        }
        
        // BUG: Components deleted, but what about shared components?
        for (auto* comp : components) {
            delete comp;
        }
    }
    
    void addComponent(Component* comp) {
        components.push_back(comp);
    }
    
    // BUG: Returns raw pointer - caller might delete it
    Component* getComponent(const std::string& name) {
        for (auto* comp : components) {
            if (comp->name == name) {
                return comp;
            }
        }
        return nullptr;
    }
    
    // BUG: Removes component but caller might still have pointer
    void removeComponent(const std::string& name) {
        for (auto it = components.begin(); it != components.end(); ++it) {
            if ((*it)->name == name) {
                delete *it;  // Deleted, but caller might have pointer
                components.erase(it);
                return;
            }
        }
    }
    
    void addChild(Entity* child) {
        child->parent = this;
        children.push_back(child);
    }
    
    // BUG: Removes child but doesn't delete - memory leak
    void removeChild(Entity* child) {
        for (auto it = children.begin(); it != children.end(); ++it) {
            if (*it == child) {
                (*it)->parent = nullptr;
                children.erase(it);
                // BUG: child not deleted - leaked
                return;
            }
        }
    }
    
    // BUG: Clone creates new entity but shares component pointers
    Entity* shallowClone() {
        Entity* clone = new Entity(name + "_clone");
        // BUG: Shallow copy - same Component pointers
        clone->components = components;  // Both entities share components!
        return clone;
    }
    
    // BUG: Deep clone doesn't handle circular references
    Entity* deepClone() {
        Entity* clone = new Entity(name + "_clone");
        
        // Clone components
        for (auto* comp : components) {
            clone->components.push_back(comp->clone());
        }
        
        // BUG: Recursive clone can overflow stack with circular refs
        for (auto* child : children) {
            clone->addChild(child->deepClone());
        }
        
        return clone;
    }
};

// =============================================================================
// Entity Manager with memory management issues
// =============================================================================

class EntityManager {
public:
    // BUG: Map of raw pointers
    std::map<int, Entity*> entities;
    int nextId = 0;
    
    // BUG: Static pointer - never freed
    static EntityManager* instance;
    
    static EntityManager* getInstance() {
        if (!instance) {
            instance = new EntityManager();  // BUG: Never deleted
        }
        return instance;
    }
    
    int createEntity(const std::string& name) {
        int id = nextId++;
        entities[id] = new Entity(name);
        return id;
    }
    
    // BUG: Returns raw pointer
    Entity* getEntity(int id) {
        auto it = entities.find(id);
        if (it != entities.end()) {
            return it->second;
        }
        return nullptr;
    }
    
    // BUG: Deletes entity but doesn't handle references from other entities
    void destroyEntity(int id) {
        auto it = entities.find(id);
        if (it != entities.end()) {
            delete it->second;  // What about parent/child references?
            entities.erase(it);
        }
    }
    
    // BUG: Clear doesn't delete entities
    void clearWrong() {
        entities.clear();  // Memory leak - entities not deleted
    }
    
    // Attempts to clear but has double-delete risk
    void clearAlsoWrong() {
        for (auto& pair : entities) {
            delete pair.second;
        }
        entities.clear();
        // BUG: If entity's destructor deletes children that are also in map,
        // we get double delete
    }
    
    // BUG: Destructor missing - singleton never cleaned up
};

EntityManager* EntityManager::instance = nullptr;

// =============================================================================
// Resource with reference counting bugs
// =============================================================================

class Texture {
public:
    unsigned char* data;
    int width, height;
    int refCount;
    
    Texture(int w, int h) : width(w), height(h), refCount(1) {
        data = new unsigned char[w * h * 4];
    }
    
    ~Texture() {
        delete[] data;
    }
    
    void addRef() {
        refCount++;
    }
    
    // BUG: release() doesn't check for negative refCount
    void release() {
        refCount--;
        if (refCount == 0) {
            delete this;
        }
        // BUG: If release() called too many times, refCount goes negative
        // and object is never deleted (memory leak) or deleted twice later
    }
};

// =============================================================================
// Array utilities with bounds issues
// =============================================================================

class DynamicArray {
public:
    int* data;
    int size;
    int capacity;
    
    DynamicArray(int initialCapacity = 10) : size(0), capacity(initialCapacity) {
        data = new int[capacity];
    }
    
    // BUG: Missing copy constructor - default does shallow copy
    // BUG: Missing copy assignment operator
    // BUG: Missing move constructor/assignment
    
    ~DynamicArray() {
        delete[] data;
    }
    
    void push(int value) {
        if (size >= capacity) {
            resize();
        }
        data[size++] = value;
    }
    
    // BUG: No bounds checking
    int& operator[](int index) {
        return data[index];  // Out of bounds not checked
    }
    
    void resize() {
        capacity *= 2;
        int* newData = new int[capacity];
        
        // Copy old data
        for (int i = 0; i < size; i++) {
            newData[i] = data[i];
        }
        
        // BUG: Old data not deleted before reassignment
        data = newData;  // Memory leak!
        // Should be: delete[] data; data = newData;
    }
    
    // BUG: pop() doesn't handle empty array
    int pop() {
        return data[--size];  // Undefined behavior if size is 0
    }
};

// =============================================================================
// String class with memory issues
// =============================================================================

class MyString {
public:
    char* buffer;
    size_t length;
    
    MyString() : buffer(nullptr), length(0) { }
    
    MyString(const char* str) {
        length = strlen(str);
        buffer = new char[length + 1];
        strcpy(buffer, str);
    }
    
    // BUG: Copy constructor - shallow copy
    MyString(const MyString& other) {
        // BUG: Should deep copy, but this is shallow
        buffer = other.buffer;  // Both share same buffer!
        length = other.length;
    }
    
    // BUG: Copy assignment operator missing
    // Default assignment would also be shallow copy
    
    ~MyString() {
        delete[] buffer;  // BUG: Double delete if copied
    }
    
    // BUG: Concatenation leaks memory
    MyString operator+(const MyString& other) {
        MyString result;
        result.length = length + other.length;
        result.buffer = new char[result.length + 1];
        strcpy(result.buffer, buffer);
        strcat(result.buffer, other.buffer);
        // BUG: If result goes out of scope immediately, buffer is deleted
        // But return value optimization might save us... or not
        return result;
    }
    
    // BUG: c_str returns internal pointer that can be invalidated
    const char* c_str() const {
        return buffer;
    }
};

}  // namespace ECS

#endif // ENTITY_SYSTEM_H
