using System;
using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem
{
    /// <summary>
    /// Inventory System with Unity serialization bugs
    /// </summary>
    
    // BUG: Class not marked [Serializable] - won't serialize in Inspector
    public class ItemData
    {
        public string itemName;
        public int quantity;
        public float weight;
    }

    // BUG: Struct serialization issues
    [Serializable]
    public struct WeaponStats
    {
        public int damage;
        public float attackSpeed;
        
        // BUG: Properties don't serialize
        public int DPS => (int)(damage * attackSpeed);
        
        // BUG: Static fields don't serialize
        public static int GlobalDamageBonus = 0;
    }

    // BUG: Generic class - Unity can't serialize generic types directly
    [Serializable]
    public class Container<T>
    {
        public T item;
        public int count;
    }

    // BUG: Interface reference - Unity can't serialize interfaces
    public interface IItem
    {
        string Name { get; }
        void Use();
    }

    [Serializable]
    public class Potion : IItem
    {
        public string potionName;
        public int healAmount;
        
        public string Name => potionName;
        public void Use() { }
    }

    /// <summary>
    /// Player Inventory with serialization bugs
    /// </summary>
    public class PlayerInventory : MonoBehaviour
    {
        [Header("Inventory Settings")]
        public int maxSlots = 20;
        
        // BUG: Dictionary doesn't serialize in Unity
        public Dictionary<string, int> itemCounts = new Dictionary<string, int>();
        
        // BUG: HashSet doesn't serialize
        public HashSet<string> discoveredItems = new HashSet<string>();
        
        // BUG: List of non-serializable class
        public List<ItemData> items = new List<ItemData>();
        
        // BUG: Interface reference won't serialize
        public IItem equippedItem;
        
        // BUG: Nullable types don't serialize
        public int? lastSelectedSlot;
        
        // BUG: Multidimensional array doesn't serialize
        public ItemData[,] inventoryGrid = new ItemData[4, 5];
        
        // BUG: Jagged array serialization is inconsistent
        public ItemData[][] equipmentSlots;
        
        // BUG: Private field without [SerializeField]
        private int gold;
        
        // BUG: Public property - properties don't serialize
        public int Gold
        {
            get => gold;
            set => gold = value;
        }
        
        // BUG: Readonly field doesn't serialize
        public readonly string inventoryVersion = "1.0";
        
        // BUG: Const doesn't serialize (by design, but often misunderstood)
        public const int MAX_STACK = 99;
        
        // BUG: Delegates/events don't serialize
        public Action<ItemData> OnItemAdded;
        public event Action<int> OnGoldChanged;
        
        // This WILL serialize - for comparison
        [SerializeField]
        private List<string> itemNames = new List<string>();
        
        void Start()
        {
            // Initialize non-serializable collections
            itemCounts["sword"] = 1;
            discoveredItems.Add("potion");
        }
        
        void OnValidate()
        {
            // BUG: OnValidate called during serialization - dangerous to modify
            if (items == null)
            {
                items = new List<ItemData>();
            }
            
            // BUG: Logging in OnValidate can spam console
            Debug.Log($"Inventory validated with {items.Count} items");
        }
    }

    /// <summary>
    /// ScriptableObject with serialization issues
    /// </summary>
    [CreateAssetMenu(fileName = "ItemDatabase", menuName = "Inventory/Item Database")]
    public class ItemDatabase : ScriptableObject
    {
        // BUG: Dictionary in ScriptableObject - won't persist
        public Dictionary<int, ItemData> itemsById = new Dictionary<int, ItemData>();
        
        // BUG: Polymorphic list - derived types won't serialize properly
        public List<ItemData> allItems = new List<ItemData>();
        
        // BUG: Self-reference without [SerializeReference]
        public ItemDatabase parentDatabase;
        
        // BUG: Circular reference
        public ItemDatabase linkedDatabase;
        
        void OnEnable()
        {
            // BUG: OnEnable called during deserialization - itemsById is empty
            RebuildDictionary();
        }
        
        void RebuildDictionary()
        {
            itemsById.Clear();
            for (int i = 0; i < allItems.Count; i++)
            {
                // BUG: allItems might contain null after deserialization
                if (allItems[i] != null)
                {
                    itemsById[i] = allItems[i];
                }
            }
        }
    }

    /// <summary>
    /// Save System with serialization bugs
    /// </summary>
    [Serializable]
    public class SaveData
    {
        public string playerName;
        public Vector3 position;  // Vector3 serializes fine
        
        // BUG: Transform doesn't serialize - it's a component reference
        public Transform playerTransform;
        
        // BUG: GameObject reference - becomes null after load
        public GameObject playerObject;
        
        // BUG: Quaternion might lose precision
        public Quaternion rotation;
        
        // BUG: Color32 vs Color serialization differences
        public Color playerColor;
        
        // BUG: UnityEngine.Object references break
        public Material playerMaterial;
        public Sprite playerIcon;
        public AudioClip footstepSound;
        
        // BUG: DateTime uses binary serialization, not JSON-friendly
        public DateTime saveTime;
        
        // BUG: Guid doesn't serialize to JSON well
        public Guid saveId;
        
        // BUG: Nested class serialization
        public SaveData nestedSave;  // Recursive reference
    }

    public class SaveManager : MonoBehaviour
    {
        public SaveData currentSave;
        
        public void Save()
        {
            currentSave = new SaveData
            {
                playerName = "Test",
                position = transform.position,
                playerTransform = transform,  // BUG: Will be null on load
                playerObject = gameObject,    // BUG: Will be null on load
                rotation = transform.rotation,
                saveTime = DateTime.Now       // BUG: Binary format
            };
            
            // BUG: JsonUtility doesn't support Dictionary, HashSet, etc.
            string json = JsonUtility.ToJson(currentSave);
            PlayerPrefs.SetString("save", json);
        }
        
        public void Load()
        {
            string json = PlayerPrefs.GetString("save");
            currentSave = JsonUtility.FromJson<SaveData>(json);
            
            // BUG: These will be null
            Debug.Log($"Transform: {currentSave.playerTransform}");  // null
            Debug.Log($"GameObject: {currentSave.playerObject}");    // null
        }
    }

    /// <summary>
    /// Polymorphism serialization bugs
    /// </summary>
    [Serializable]
    public class BaseItem
    {
        public string name;
        public int value;
    }

    [Serializable]
    public class Weapon : BaseItem
    {
        public int damage;
        public float range;
    }

    [Serializable]
    public class Armor : BaseItem
    {
        public int defense;
        public float weight;
    }

    public class Equipment : MonoBehaviour
    {
        // BUG: Polymorphic serialization - derived data lost
        public List<BaseItem> items = new List<BaseItem>();
        
        // BUG: Without [SerializeReference], only BaseItem fields serialize
        public BaseItem weapon;  // Will lose Weapon-specific data
        public BaseItem armor;   // Will lose Armor-specific data
        
        // Correct way (Unity 2019.3+)
        [SerializeReference]
        public List<BaseItem> properItems = new List<BaseItem>();
        
        void Start()
        {
            // Add derived types
            items.Add(new Weapon { name = "Sword", damage = 10 });
            items.Add(new Armor { name = "Shield", defense = 5 });
            
            // BUG: After serialize/deserialize, damage and defense will be 0
        }
    }

    /// <summary>
    /// Custom class in arrays
    /// </summary>
    public class GridInventory : MonoBehaviour
    {
        // BUG: 2D array doesn't serialize
        public ItemData[,] grid;
        
        // Workaround that also has issues
        [Serializable]
        public class InventoryRow
        {
            public ItemData[] items;  // BUG: ItemData not [Serializable]
        }
        
        public InventoryRow[] rows;
        
        // BUG: List of arrays - outer list serializes, inner behavior varies
        public List<ItemData[]> itemArrays;
        
        void Awake()
        {
            grid = new ItemData[4, 5];
            
            // BUG: grid will be null after assembly reload in editor
        }
    }

    /// <summary>
    /// Unity Object references in serializable classes
    /// </summary>
    [Serializable]
    public class ItemSpawnData
    {
        public string itemId;
        public Vector3 spawnPosition;
        
        // BUG: Prefab reference in [Serializable] class - works in MonoBehaviour only
        public GameObject prefab;
        
        // BUG: Component references don't work in plain classes
        public Collider spawnTrigger;
    }

    public class ItemSpawner : MonoBehaviour
    {
        // This works because it's on a MonoBehaviour
        public GameObject prefab;
        
        // BUG: List of classes with Unity Object references
        public List<ItemSpawnData> spawnPoints;
        
        void SpawnItems()
        {
            foreach (var spawn in spawnPoints)
            {
                // BUG: spawn.prefab will be null if this class is serialized/deserialized
                if (spawn.prefab != null)
                {
                    Instantiate(spawn.prefab, spawn.spawnPosition, Quaternion.identity);
                }
            }
        }
    }
}
