# Android Lifecycle Bugs - Notes App

A Notes application demonstrating common Android lifecycle and threading bugs.

## Difficulty: ⭐⭐⭐⭐

## Bug Categories

### Memory Leaks
- Static Activity reference in companion object
- Handler created with default looper (implicit Activity reference)
- Timer/TimerTask holding Activity reference
- Anonymous inner class listener holding outer class reference
- Fragment holding Activity reference after detach

### Threading Violations
- Database operations on main thread (ANR risk)
- UI updates from background threads (CalledFromWrongThreadException)
- Handler posts from Timer thread
- Missing runOnUiThread for background results

### Lifecycle Mismanagement
- Not removing listeners in onDestroy
- Not cancelling Timer in onDestroy
- Not removing Handler callbacks in onDestroy
- Static reference not cleared on destroy
- Fragment lateinit accessed before initialization
- requireActivity() in coroutine that outlives Fragment

### State Handling
- Saving heavy data in onSaveInstanceState (TransactionTooLargeException)
- Configuration change handling that loses state
- Using configChanges attribute to avoid rotation (bad practice)

## Expected Behavior

### What Should Happen
- Notes app launches without memory leaks
- Configuration changes preserve state
- Background operations don't block UI
- Listeners cleaned up when Activity destroyed
- Fragments safely access Activity

### What Actually Happens
- Memory leaks when rotating device
- ANR when loading notes
- Crash: CalledFromWrongThreadException
- TransactionTooLargeException with many notes
- UninitializedPropertyAccessException in Fragment
- IllegalStateException: Fragment not attached

## Build & Run

```bash
./gradlew assembleDebug
./gradlew installDebug
```

## Testing for Bugs

### Memory Leak Detection
1. Rotate device repeatedly
2. Use LeakCanary or Memory Profiler
3. Check for retained MainActivity instances

### Threading Issues
1. Add many notes (100+)
2. Open app - observe ANR dialog
3. Check logcat for CalledFromWrongThreadException

### State Issues
1. Create 1000+ notes with large content
2. Rotate device
3. Observe TransactionTooLargeException crash

### Fragment Crashes
1. Open note detail
2. Rotate while note is loading
3. Observe crash from lateinit or requireActivity()

## Project Structure

```
app/src/main/java/com/notes/
├── ui/
│   └── MainActivity.kt      # Lifecycle bugs, Fragment with issues
├── model/
│   └── Note.kt              # Data model with Parcelable
└── data/
    ├── NotesDatabase.kt     # Room database
    └── NotesRepository.kt   # Listener pattern (leak-prone)
```

## Key Files to Examine

1. **MainActivity.kt** - Most bugs concentrated here
   - Static companion object references
   - Handler/Timer without cleanup
   - Background thread UI updates
   - Missing onDestroy cleanup

2. **NoteDetailFragment** - Fragment lifecycle bugs
   - lateinit before initialization
   - requireActivity() in coroutine
   - Activity reference leak

3. **NotesRepository.kt** - Listener pattern issues
   - Callbacks from wrong thread
   - No lifecycle awareness
