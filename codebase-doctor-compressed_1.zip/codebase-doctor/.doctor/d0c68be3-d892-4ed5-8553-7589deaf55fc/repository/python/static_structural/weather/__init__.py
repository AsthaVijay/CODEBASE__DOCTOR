# Weather package
# BUG: This import creates a circular dependency with models.py
from weather.api import WeatherAPI
from weather.models import WeatherData, Forecast
