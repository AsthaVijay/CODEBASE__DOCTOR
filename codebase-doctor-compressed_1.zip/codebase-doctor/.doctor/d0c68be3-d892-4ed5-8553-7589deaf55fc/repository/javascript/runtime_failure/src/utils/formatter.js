/**
 * Data Formatting Utilities
 */

function formatCommit(commit) {
    // BUG: commit might be undefined or have missing fields
    return {
        id: commit.id.substring(0, 7),
        message: commit.message.split('\n')[0], // First line only
        author: commit.author.name,
        timestamp: new Date(commit.timestamp).toISOString()
    };
}

function formatCurrency(amount, currency = 'usd') {
    // BUG: amount might be a string, need to convert
    // BUG: Assuming amount is already in dollars, but Stripe sends cents
    const symbols = {
        usd: '$',
        eur: '€',
        gbp: '£'
    };
    
    // BUG: symbol might be undefined for unsupported currencies
    const symbol = symbols[currency.toLowerCase()];
    return `${symbol}${amount}`;
}

function formatDate(input) {
    // BUG: Doesn't handle Unix timestamps (needs * 1000)
    const date = new Date(input);
    
    // BUG: Doesn't check if date is valid
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function truncate(text, maxLength = 100) {
    // BUG: text might be null/undefined
    if (text.length <= maxLength) {
        return text;
    }
    return text.substring(0, maxLength - 3) + '...';
}

module.exports = {
    formatCommit,
    formatCurrency,
    formatDate,
    truncate
};
