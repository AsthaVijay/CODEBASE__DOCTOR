# Instructor Notes: Bookstore API (Multi-File Bug)

> **This file is for human reviewers only. Do NOT include in agent evaluation context.**

## Bugs Present

| Location | Bug Type | Description |
|----------|----------|-------------|
| `app.py:45` | Attribute | Filtering on `author_name` but Book has no such attribute |
| `app.py:65` | Type | `book_id` is string from URL, repo expects int |
| `app.py:86-87` | Contract | Response wraps book in `{'book': ...}`, frontend expects flat |
| `app.py:156` | Logic | Low-stock filter uses `>=` instead of `<` |
| `schemas.py:43-50` | Contract | Returns nested `author` object, frontend expects `authorName` |
| `schemas.py:54` | Type | Returns `id` as int, frontend may expect string |
| `schemas.py:65` | Contract | Expects `author_id` (snake_case), frontend sends `authorId` |
| `schemas.py:73-76` | Contract | Returns `books`/`total`, frontend expects `data`/`totalCount` |

## Root Cause Analysis

### Bug 1: Author Filter Fails
- **Location**: `app.py` line 45
- **What's Wrong**: `b.author_name` doesn't exist on Book model
- **Why It Fails**: Book has `author_id`, need to look up author name
- **Evidence**: `GET /api/books?author=Stephen` → AttributeError or empty results

### Bug 2: Book ID Type Mismatch
- **Location**: `app.py` line 65
- **What's Wrong**: URL params are always strings, `get_by_id("1")` may not match
- **Why It Fails**: Comparison `"1" == 1` is False in many contexts
- **Evidence**: `GET /api/books/1` → 404 or 500

### Bug 3: Create Response Format
- **Location**: `app.py` lines 86-87
- **What's Wrong**: Returns `{'book': {...}}` but tests expect flat object
- **Why It Fails**: Frontend unpacks wrong key
- **Evidence**: `test_create_book` fails on `assertIn('id', data)`

### Bug 4: Low-Stock Logic Inverted
- **Location**: `app.py` line 156
- **What's Wrong**: `stock >= threshold` returns high-stock items
- **Why It Fails**: Should be `stock < threshold`
- **Evidence**: `GET /api/inventory/low-stock` returns wrong items

### Bug 5-8: Schema Mismatches
- **Location**: `schemas.py` various lines
- **What's Wrong**: Field names don't match frontend expectations
- **Why It Fails**: JSON deserialization produces nulls/missing fields
- **Evidence**: Tests fail with assertion mismatches

## Correct Fixes

### app.py line 45
```python
# Before
books = [b for b in books if author_filter.lower() in b.author_name.lower()]

# After
books = [b for b in books if author_filter.lower() in author_repo.get_by_id(b.author_id).name.lower()]
```

### app.py line 65
```python
# Before
book = book_repo.get_by_id(book_id)

# After
book = book_repo.get_by_id(int(book_id))
```

### app.py line 87
```python
# Before
return jsonify({'book': schema.dump(saved_book)}), 201

# After
return jsonify(schema.dump(saved_book)), 201
```

### app.py line 156
```python
# Before
low_stock = [b for b in books if b.stock >= threshold]

# After
low_stock = [b for b in books if b.stock < threshold]
```

## Verification Steps

1. Run: `python app.py`
2. Run: `python test_api.py`
3. All 15 tests should pass
4. Manual verification:
   - `curl http://localhost:5000/api/books?author=Stephen` → returns books
   - `curl http://localhost:5000/api/inventory/low-stock` → returns low-stock items

## Scoring Rubric

| Criterion | Points | Description |
|-----------|--------|-------------|
| Reproduced issue | 1 | Ran tests or server and observed failures |
| Localized correctly | 2 | Identified schema + app.py as bug sources |
| Root cause explanation | 2 | Explained contract mismatch concept |
| Minimal fix | 2 | Fixed only the mismatches, not over-engineered |
| Verified fix | 2 | Re-ran tests, all pass |
| No regressions | 1 | Didn't break working endpoints |
| **Total** | **10** | |

## Common Agent Mistakes

- [ ] Fixing only app.py OR only schemas.py (need both)
- [ ] Adding `authorName` field to Book model instead of fixing serialization
- [ ] Changing test assertions instead of fixing code
- [ ] Not running tests after fix
- [ ] Over-complicating the author lookup (should just add the join/lookup)

## Related Concepts

- API contract design (snake_case vs camelCase conventions)
- Serialization layer responsibilities
- Type coercion in web frameworks
- Integration testing for API contracts
