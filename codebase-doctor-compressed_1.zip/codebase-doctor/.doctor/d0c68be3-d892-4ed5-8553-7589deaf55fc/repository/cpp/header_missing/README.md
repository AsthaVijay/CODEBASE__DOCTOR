# C++ Header/Include Issues - Game Engine Framework

A game engine framework demonstrating common C++ header and include-related bugs.

## Difficulty: ⭐⭐⭐⭐

## Bug Categories

### Missing Include Guards
- `GameTypes.h` - No include guard, causes redefinition errors
- `Components.h` - No include guard, multiply included
- `Entity.h` - `#ifndef` opened but `#endif` missing

### Circular Dependencies
- `GameTypes.h` ↔ `Components.h` - Each includes the other
- `Entity.h` ↔ `World.h` - Each includes the other
- Results in incomplete type errors and compilation failure

### Missing Standard Library Includes
- `std::string` used without `<string>`
- `std::vector` used without `<vector>`
- `std::map` used without `<map>`
- `std::unique_ptr/shared_ptr` without `<memory>`
- `std::function` without `<functional>`
- `std::cout/cerr` without `<iostream>`
- `std::sin/cos/sqrt` without `<cmath>`
- `std::clamp/find/remove` without `<algorithm>`
- `std::chrono` types without `<chrono>`
- `std::type_index` without `<typeindex>`
- `std::optional` without `<optional>`
- `std::stringstream` without `<sstream>`
- `std::queue` without `<queue>`
- `std::array` without `<array>`
- `size_t` without `<cstddef>`
- `uint32_t` without `<cstdint>`
- `assert` without `<cassert>`
- `std::is_base_of` without `<type_traits>`

### Incomplete Type Errors
- `EntityData` contains `Transform` by value but `Transform` only forward declared
- `Entity* owner` accessed through incomplete type
- Template methods call functions on incomplete types

### ODR (One Definition Rule) Violations
- `Entity::nextId` static member defined in header (not inline)
- `initializeDefaultWorld()` function defined in header (not inline)
- Including these headers in multiple .cpp files causes multiple definition errors at link time

### Template Issues
- Template classes using types without includes
- Template methods calling unavailable member functions
- Partial template specialization without necessary includes

## Expected Errors

### Compilation Errors
```
GameTypes.h:15:5: error: 'string' is not a member of 'std'
GameTypes.h:16:5: error: 'vector' is not a member of 'std'
GameTypes.h:17:5: error: field 'transform' has incomplete type 'Game::Transform'
Components.h:12:5: error: 'cout' is not a member of 'std'
Entity.h:45:5: error: 'type_index' is not a member of 'std'
```

### Linker Errors (if compilation succeeds)
```
multiple definition of `Game::Entity::nextId'
multiple definition of `Game::initializeDefaultWorld(Game::World&)'
```

## Build & Run

```bash
mkdir build && cd build
cmake ..
make
# Build will fail with many errors
```

## Error Summary

| Error Type | Location | Symptom |
|------------|----------|---------|
| Missing Guard | GameTypes.h | Redefinition errors |
| Circular Include | GameTypes↔Components | Incomplete type |
| Missing Include | Throughout | 'X' is not a member of 'std' |
| Incomplete Type | EntityData::transform | Field has incomplete type |
| ODR Violation | Entity::nextId | Multiple definition (linker) |
| ODR Violation | initializeDefaultWorld | Multiple definition (linker) |
| Missing #endif | Entity.h | Unterminated #ifndef |

## Key Files to Examine

1. **include/GameTypes.h** - No guard, circular with Components.h
2. **include/Components.h** - No guard, missing std includes
3. **include/Entity.h** - Missing #endif, ODR violation with static
4. **include/World.h** - Proper #pragma once, but includes broken headers
5. **src/main.cpp** - Uses all broken headers
6. **src/helper.cpp** - Second TU exposes ODR violations

## Project Structure

```
header_missing/
├── CMakeLists.txt
├── include/
│   ├── GameTypes.h      # Missing guard, circular include
│   ├── Components.h     # Missing guard, missing includes
│   ├── Entity.h         # Missing #endif, ODR issues
│   └── World.h          # Has #pragma once, uses broken headers
├── src/
│   ├── main.cpp         # Primary translation unit
│   └── helper.cpp       # Second TU for ODR demonstration
└── README.md
```

## Correct Patterns (Reference)

### Include Guards
```cpp
// Option 1: Traditional guard
#ifndef MYHEADER_H
#define MYHEADER_H
// ... content ...
#endif // MYHEADER_H

// Option 2: Pragma once (non-standard but widely supported)
#pragma once
```

### Breaking Circular Dependencies
```cpp
// Forward declare when you only need pointers/references
class Entity;  // Forward declaration

class Component {
    Entity* owner;  // OK - pointer to forward declared type
};

// Include when you need the full definition
#include "Entity.h"  // Need full definition for member functions
```

### Proper Standard Library Usage
```cpp
#include <string>      // std::string
#include <vector>      // std::vector
#include <memory>      // std::unique_ptr, std::shared_ptr
#include <functional>  // std::function
#include <cmath>       // std::sin, std::cos, std::sqrt
```

### Avoiding ODR Violations
```cpp
// In header: declare, don't define
class Entity {
    static uint32_t nextId;  // Declaration only
};

// In .cpp: define once
uint32_t Entity::nextId = 0;  // Definition

// Or use inline (C++17)
class Entity {
    inline static uint32_t nextId = 0;  // OK in header
};
```

## Detection Tools

1. **Compiler** - Will catch most errors at compile/link time
2. **include-what-you-use** - Analyzes include dependencies
3. **cppcheck** - Static analysis for missing includes
4. **clangd** - IDE integration for include diagnostics
