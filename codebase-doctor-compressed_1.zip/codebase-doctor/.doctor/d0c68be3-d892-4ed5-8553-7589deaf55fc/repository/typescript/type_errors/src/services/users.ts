/**
 * User Service
 */

import { HttpClient } from './client';
import { User, CreateUserInput, UpdateUserInput, UserResponse, isValidUser } from '../models/user';
import { ApiResponse, PaginatedResponse } from '../models/response';
import { transformUserResponse } from '../utils/transform';

export class UserService {
    private client: HttpClient;

    constructor(client: HttpClient) {
        this.client = client;
    }

    // BUG: Returns Promise<ApiResponse<User[]>> but transformation returns User, not User[]
    async getUsers(page = 1, pageSize = 10): Promise<PaginatedResponse<User[]>> {
        // BUG: API returns UserResponse[], not User[]
        const response = await this.client.get<UserResponse[]>('/users', {
            params: { page, pageSize }
        });

        if (!response.success) {
            // BUG: Return type mismatch - returning ApiResponse but expected PaginatedResponse
            return response;
        }

        // BUG: data might be undefined when success is true
        const users = response.data.map(transformUserResponse);

        // BUG: Missing meta property required by PaginatedResponse
        return {
            success: true,
            data: users
        };
    }

    // BUG: Return type says User but might return undefined
    async getUser(id: number): Promise<User> {
        const response = await this.client.get<UserResponse>(`/users/${id}`);

        if (!response.success) {
            // BUG: Throwing string, not Error
            throw response.error?.message;
        }

        // BUG: response.data might be undefined
        return transformUserResponse(response.data);
    }

    // BUG: CreateUserInput email is optional but API requires it
    async createUser(input: CreateUserInput): Promise<User> {
        // BUG: Sending input directly but API expects different shape
        const response = await this.client.post<UserResponse, CreateUserInput>(
            '/users',
            input
        );

        if (!response.success) {
            throw new Error(response.error?.message || 'Failed to create user');
        }

        return transformUserResponse(response.data);
    }

    // BUG: UpdateUserInput allows setting id and createdAt
    async updateUser(id: number, updates: UpdateUserInput): Promise<User> {
        // BUG: id is in both URL and potentially in updates object
        const response = await this.client.put<UserResponse, UpdateUserInput>(
            `/users/${id}`,
            updates
        );

        if (!response.success) {
            throw new Error(response.error?.message);
        }

        return transformUserResponse(response.data);
    }

    async deleteUser(id: number): Promise<void> {
        const response = await this.client.delete(`/users/${id}`);

        // BUG: Checking success but not handling the error case properly
        if (response.success) {
            return;
        }
        // BUG: Falls through without throwing
    }

    // BUG: Filter function type is wrong - should be (user: User) => boolean
    async findUsers(filter: (user: UserResponse) => boolean): Promise<User[]> {
        const response = await this.getUsers(1, 100);
        
        if (!response.success) {
            return [];
        }

        // BUG: response.data is User[] but filter expects UserResponse
        return response.data.filter(filter);
    }

    // BUG: Validation uses isValidUser which checks User shape, not UserResponse
    async validateAndCreate(data: unknown): Promise<User> {
        if (!isValidUser(data)) {
            throw new Error('Invalid user data');
        }

        // BUG: data is narrowed to User but createUser expects CreateUserInput
        return this.createUser(data);
    }
}
