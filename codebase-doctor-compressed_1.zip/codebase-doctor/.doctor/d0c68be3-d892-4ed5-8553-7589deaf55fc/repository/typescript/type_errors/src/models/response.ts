/**
 * API Response Type Definitions
 */

// BUG: Generic constraint is too loose
export interface ApiResponse<T> {
    success: boolean;
    data: T;
    error?: ApiError;
    meta?: ResponseMeta;
}

export interface ApiError {
    code: string;
    message: string;
    details?: Record<string, unknown>;
}

export interface ResponseMeta {
    page: number;
    pageSize: number;
    total: number;
    hasMore: boolean;
}

// BUG: PaginatedResponse data should be T[] not T
export interface PaginatedResponse<T> extends ApiResponse<T> {
    // data is T (single item) but should be T[] for pagination
    meta: ResponseMeta;  // BUG: meta is optional in ApiResponse but required here (conflict)
}

// BUG: This type doesn't properly extract the data type
export type ExtractData<R> = R extends ApiResponse<infer T> ? T : never;

// BUG: Union type handling - doesn't narrow properly
export type ApiResult<T> = 
    | { success: true; data: T }
    | { success: false; error: ApiError };

// BUG: This function doesn't properly narrow the union type
export function handleResult<T>(result: ApiResult<T>): T {
    if (result.success) {
        return result.data;
    }
    // BUG: TypeScript still thinks result could have data here
    // because both branches have success property
    throw new Error(result.error.message);
}

// BUG: Overloaded function signatures don't match implementation
export function createResponse<T>(data: T): ApiResponse<T>;
export function createResponse<T>(data: T, meta: ResponseMeta): PaginatedResponse<T>;
export function createResponse<T>(
    data: T,
    meta?: ResponseMeta
): ApiResponse<T> | PaginatedResponse<T> {
    // BUG: Implementation doesn't properly handle the overloads
    return {
        success: true,
        data,
        meta
    };
}

// BUG: Type assertion without validation
export function parseResponse<T>(json: string): ApiResponse<T> {
    const parsed = JSON.parse(json);
    // BUG: No runtime validation that parsed matches ApiResponse<T>
    return parsed as ApiResponse<T>;
}
