/**
 * Retry utility for handling transient failures
 */

export interface RetryOptions {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

const defaultOptions: RetryOptions = {
  maxAttempts: 3,
  baseDelay: 100,
  maxDelay: 5000,
  backoffMultiplier: 2
};

/**
 * Execute a function with retry logic
 * BUG: Missing await on the recursive call
 * BUG: Delay calculation doesn't await properly
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  options: Partial<RetryOptions> = {}
): Promise<T> {
  const opts = { ...defaultOptions, ...options };
  let lastError: Error | null = null;
  
  for (let attempt = 1; attempt <= opts.maxAttempts; attempt++) {
    try {
      // BUG: Should return await fn() to properly catch async errors
      return fn();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt < opts.maxAttempts) {
        const delay = calculateDelay(attempt, opts);
        console.log(`  Retry attempt ${attempt}/${opts.maxAttempts} after ${delay}ms`);
        
        // BUG: Not awaiting the delay - continues immediately
        sleep(delay);
      }
    }
  }
  
  throw lastError || new Error('Retry failed');
}

/**
 * Calculate exponential backoff delay
 */
function calculateDelay(attempt: number, options: RetryOptions): number {
  const delay = options.baseDelay * Math.pow(options.backoffMultiplier, attempt - 1);
  return Math.min(delay, options.maxDelay);
}

/**
 * Sleep for specified milliseconds
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retry with timeout - race between operation and timeout
 * BUG: Promise.race doesn't cancel the losing promise
 * BUG: Timeout error not properly typed
 */
export async function withRetryAndTimeout<T>(
  fn: () => Promise<T>,
  timeoutMs: number,
  retryOptions: Partial<RetryOptions> = {}
): Promise<T> {
  const timeoutPromise = new Promise<T>((_, reject) => {
    setTimeout(() => {
      // BUG: This creates an unhandled rejection if fn() succeeds first
      reject('Operation timed out');
    }, timeoutMs);
  });
  
  // BUG: Should wrap withRetry result, but timeout keeps running
  // BUG: No cleanup of timeout when retry succeeds
  return Promise.race([
    withRetry(fn, retryOptions),
    timeoutPromise
  ]);
}

/**
 * Execute multiple operations with individual retries
 * BUG: Promise.all fails fast - one failure loses all results
 * BUG: No error aggregation
 */
export async function retryAll<T>(
  operations: Array<() => Promise<T>>,
  options: Partial<RetryOptions> = {}
): Promise<T[]> {
  // BUG: If one fails, others that succeeded are lost
  // Should use Promise.allSettled instead
  return Promise.all(
    operations.map(op => withRetry(op, options))
  );
}
