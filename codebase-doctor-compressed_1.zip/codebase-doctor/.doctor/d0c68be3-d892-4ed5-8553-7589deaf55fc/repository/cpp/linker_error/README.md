# C++ Linker Error - Game Engine

A Game Engine project demonstrating common C++ linker errors.

## Difficulty: ⭐⭐⭐⭐

## Bug Categories

### Undefined Reference Errors

#### Static Member Not Defined
```cpp
// Header declares:
class GameConfig {
    static int screenWidth;  // Declaration
};

// .cpp missing:
int GameConfig::screenWidth;  // Definition needed
```

#### Virtual Destructor Not Defined
```cpp
class Component {
    virtual ~Component();  // Declared but never defined
};
// Linker error: undefined reference to `Component::~Component()`
```

#### Extern Variables Not Defined
```cpp
extern Renderer* globalRenderer;  // Declared in header
// Never defined anywhere - linker error
```

#### Friend Functions Not Defined
```cpp
friend Vector2 operator+(const Vector2& a, const Vector2& b);
// Declared friend but no implementation
```

#### Namespace Functions Not Implemented
```cpp
namespace MathUtils {
    float lerp(float a, float b, float t);  // Declared, not defined
}
```

### Multiple Definition Errors

#### Non-Inline Function in Header
```cpp
// In header file (included by multiple .cpp files):
int calculateDamage(int baseDamage, int armor) {
    return baseDamage - (armor / 2);
}
// Results in: multiple definition of `calculateDamage`
```

### Template Linker Issues

#### Template Implementation in .cpp
```cpp
// Header:
template<typename T>
class ResourceManager {
    void load(const std::string& path);  // Declaration only
};

// .cpp:
template<>
void ResourceManager<std::string>::load(...) { }  // Only string works
// Using ResourceManager<int> causes undefined reference
```

## Expected Behavior

### What Should Happen
- Project compiles and links successfully
- All symbols resolve correctly
- Executable runs without errors

### What Actually Happens
```
undefined reference to `GameConfig::screenWidth'
undefined reference to `GameConfig::screenHeight'
undefined reference to `Component::~Component()'
undefined reference to `AudioManager::getInstance()'
undefined reference to `MathUtils::lerp(float, float, float)'
undefined reference to `operator+(Vector2 const&, Vector2 const&)'
undefined reference to `globalRenderer'
undefined reference to `engineVersion'
```

## Build & Run

```bash
mkdir build && cd build
cmake ..
make
# Expected: Linker errors
```

## Linker Error Categories

| Error Type | Example Symbol | Cause |
|------------|---------------|-------|
| Static member | `GameConfig::screenWidth` | Missing definition |
| Virtual method | `Component::~Component()` | Declared not defined |
| Extern variable | `globalRenderer` | Never defined |
| Friend function | `operator+` | Declaration only |
| Template | `ResourceManager<int>::load` | Impl in .cpp |
| Free function | `MathUtils::lerp` | Not implemented |

## Key Files to Examine

1. **include/GameEngine.h** - Declarations with issues
   - Static member declarations
   - Virtual destructor declaration
   - Extern declarations
   - Template class declarations
   - Friend function declarations

2. **src/GameEngine.cpp** - Missing definitions
   - Partial static member definitions
   - Missing virtual destructor
   - Missing function implementations
   - Template specialization issues

3. **src/main.cpp** - Uses all broken symbols

## Project Structure

```
linker_error/
├── CMakeLists.txt
├── include/
│   └── GameEngine.h     # Declarations
├── src/
│   ├── main.cpp         # Uses broken symbols
│   └── GameEngine.cpp   # Missing definitions
└── README.md
```

## Common Fixes (Reference)

```cpp
// Static member - add in .cpp:
int GameConfig::screenWidth = 0;

// Virtual destructor - define:
Component::~Component() { }

// Extern variable - define:
Renderer* globalRenderer = nullptr;

// Friend function - define:
Vector2 operator+(const Vector2& a, const Vector2& b) {
    return Vector2(a.x + b.x, a.y + b.y);
}

// Template - put implementation in header:
template<typename T>
void ResourceManager<T>::load(const std::string& path) {
    // Implementation in header
}

// Non-inline function - make inline:
inline int calculateDamage(int baseDamage, int armor) {
    return baseDamage - (armor / 2);
}
```
