/**
 * Event processor - handles event processing with parallelism
 */

import { Event, EventQueue } from './queue.js';
import { ResultStorage, ProcessingResult } from './storage.js';
import { ConcurrencyLimiter } from '../utils/limiter.js';
import { withRetry, withRetryAndTimeout } from '../utils/retry.js';

export interface ProcessorConfig {
  maxConcurrent: number;
  timeoutMs: number;
  retryAttempts: number;
}

export interface EventHandler {
  (event: Event): Promise<unknown>;
}

export class EventProcessor {
  private queue: EventQueue;
  private storage: ResultStorage;
  private limiter: ConcurrencyLimiter;
  private config: ProcessorConfig;
  private handlers: Map<string, EventHandler> = new Map();
  
  // BUG: Shared mutable state for tracking
  private processedCount = 0;
  private isRunning = false;
  
  constructor(
    queue: EventQueue,
    storage: ResultStorage,
    config: Partial<ProcessorConfig> = {}
  ) {
    this.queue = queue;
    this.storage = storage;
    this.config = {
      maxConcurrent: config.maxConcurrent ?? 3,
      timeoutMs: config.timeoutMs ?? 5000,
      retryAttempts: config.retryAttempts ?? 3
    };
    this.limiter = new ConcurrencyLimiter(this.config.maxConcurrent);
  }
  
  /**
   * Register handler for event type
   */
  registerHandler(eventType: string, handler: EventHandler): void {
    this.handlers.set(eventType, handler);
  }
  
  /**
   * Process all events in queue
   * BUG: Missing await on critical async operations
   */
  async processAll(): Promise<ProcessingResult[]> {
    this.isRunning = true;
    const results: ProcessingResult[] = [];
    
    // BUG: Not awaiting storage initialization
    this.storage.initialize();
    
    console.log('Starting event pipeline...');
    
    // Get all pending events
    const stats = this.queue.getStats();
    console.log(`✓ Processing ${stats.pending} events in parallel (max ${this.config.maxConcurrent} concurrent)`);
    
    // Process events with concurrency limit
    while (true) {
      const event = await this.queue.dequeue();
      if (!event) break;
      
      // BUG: Fire and forget - not collecting all results properly
      this.limiter.execute(async () => {
        const result = await this.processEvent(event);
        results.push(result);
        
        // BUG: Not awaiting storage save
        this.storage.saveResult(result);
      });
    }
    
    // BUG: Returns before all parallel tasks complete
    // Results array will be incomplete
    
    this.isRunning = false;
    
    // BUG: Not awaiting finalize
    this.storage.finalize();
    
    console.log('✓ All events processed successfully');
    console.log(`Results saved to output.json`);
    
    return results;
  }
  
  /**
   * Process a single event
   * BUG: Error handling doesn't properly propagate
   */
  async processEvent(event: Event): Promise<ProcessingResult> {
    const startTime = Date.now();
    
    try {
      const handler = this.handlers.get(event.type);
      
      if (!handler) {
        throw new Error(`No handler registered for event type: ${event.type}`);
      }
      
      // Process with retry and timeout
      // BUG: withRetryAndTimeout has its own bugs that compound here
      const output = await withRetryAndTimeout(
        () => handler(event),
        this.config.timeoutMs,
        { maxAttempts: this.config.retryAttempts }
      );
      
      const duration = Date.now() - startTime;
      
      // BUG: Not awaiting markCompleted
      this.queue.markCompleted(event.id);
      
      // BUG: Race condition incrementing shared counter
      this.processedCount++;
      
      console.log(`  ✓ Event ${event.id.substring(0, 8)} processed (${duration}ms)`);
      
      return {
        eventId: event.id,
        status: 'success',
        output,
        duration,
        processedAt: Date.now()
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      
      // BUG: Not awaiting markFailed
      this.queue.markFailed(event.id, error as Error);
      
      console.log(`  ✗ Event ${event.id.substring(0, 8)} failed: ${(error as Error).message}`);
      
      return {
        eventId: event.id,
        status: 'error',
        error: (error as Error).message,
        duration,
        processedAt: Date.now()
      };
    }
  }
  
  /**
   * Process events in batches
   * BUG: Promise.all fails fast, losing partial results
   */
  async processBatch(events: Event[]): Promise<ProcessingResult[]> {
    // BUG: If one fails, all results are lost
    return Promise.all(
      events.map(event => this.processEvent(event))
    );
  }
  
  /**
   * Process with timeout per event
   * BUG: Timeout doesn't cancel the actual operation
   */
  async processWithTimeout(event: Event, timeoutMs: number): Promise<ProcessingResult> {
    const timeoutPromise = new Promise<ProcessingResult>((_, reject) => {
      setTimeout(() => reject(new Error('Processing timeout')), timeoutMs);
    });
    
    // BUG: processEvent keeps running even after timeout
    // Resources/side effects continue despite "timeout"
    return Promise.race([
      this.processEvent(event),
      timeoutPromise
    ]);
  }
  
  /**
   * Wait for all processing to complete
   * BUG: Doesn't actually wait for limiter queue to drain
   */
  async waitForCompletion(): Promise<void> {
    // BUG: Only checks isRunning flag, not actual pending work
    while (this.isRunning) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // BUG: Limiter might still have queued tasks
    // Should check limiter.getQueueLength() and limiter.getRunningCount()
  }
  
  /**
   * Get processing statistics
   */
  getStats(): { processed: number; running: number; queued: number } {
    return {
      processed: this.processedCount,
      running: this.limiter.getRunningCount(),
      queued: this.limiter.getQueueLength()
    };
  }
}

/**
 * Process events from multiple queues
 * BUG: Race condition between queues
 */
export async function processMultipleQueues(
  queues: EventQueue[],
  processor: EventProcessor
): Promise<ProcessingResult[]> {
  const allResults: ProcessingResult[] = [];
  
  // BUG: Processing queues in parallel without coordination
  // Events might be processed out of priority order across queues
  const promises = queues.map(async (queue) => {
    while (true) {
      const event = await queue.dequeue();
      if (!event) break;
      
      // BUG: Not awaiting before next iteration
      const result = processor.processEvent(event);
      allResults.push(await result);
    }
  });
  
  // BUG: allResults modified concurrently, final array may have holes
  await Promise.all(promises);
  
  return allResults;
}
