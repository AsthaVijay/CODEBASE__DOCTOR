/**
 * Data Transformation Utilities
 */

import { User, UserResponse, UserRole } from '../models/user';

// BUG: Parameter type is UserResponse but might receive undefined
export function transformUserResponse(response: UserResponse): User {
    return {
        // BUG: UserResponse has user_id, not id
        id: response.user_id,
        // BUG: UserResponse has username, not name
        name: response.username,
        email: response.email,
        // BUG: response.role is string, needs to be cast to UserRole
        role: response.role as UserRole,
        // BUG: Dates are strings in response, need proper parsing
        createdAt: new Date(response.created_at),
        updatedAt: new Date(response.updated_at)
        // BUG: Missing profile property - User requires it to be present or undefined
    };
}

// BUG: Return type says string but might return undefined
export function formatUserName(user: User): string {
    // BUG: profile might be undefined
    if (user.profile.avatar) {
        return `${user.name} (${user.profile.avatar})`;
    }
    return user.name;
}

// BUG: Generic constraint is too loose - T could be anything
export function transformArray<T, R>(
    items: T[],
    transformer: (item: T) => R
): R[] {
    // BUG: items might be undefined/null
    return items.map(transformer);
}

// BUG: Partial<User> means all properties are optional, including id
export function mergeUserUpdates(user: User, updates: Partial<User>): User {
    return {
        ...user,
        ...updates,
        // BUG: updatedAt should be set to now, but might be overwritten by updates
        updatedAt: new Date()
    };
}

// BUG: Type guard doesn't properly narrow
export function isUserRole(value: string): value is UserRole {
    // BUG: Includes 'moderator' which isn't a valid UserRole
    return ['admin', 'user', 'guest', 'moderator'].includes(value);
}

// BUG: Overload doesn't match implementation
export function normalizeRole(role: string): UserRole;
export function normalizeRole(role: undefined): undefined;
export function normalizeRole(role: string | undefined): UserRole | undefined {
    if (!role) {
        // BUG: Returns 'guest' string but signature says undefined
        return 'guest';
    }
    
    // BUG: toLowerCase might not match UserRole type
    const normalized = role.toLowerCase();
    
    if (isUserRole(normalized)) {
        return normalized;
    }
    
    // BUG: Returns string literal that isn't narrowed to UserRole
    return 'user';
}

// BUG: Transformer function has wrong signature
type UserTransformer = (user: User) => User;

export function applyTransformers(
    user: User,
    transformers: UserTransformer[]
): User {
    // BUG: reduce accumulator type doesn't match
    return transformers.reduce(
        (result, transformer) => transformer(result),
        user
    );
}

// BUG: Pick utility used incorrectly
type UserSummary = Pick<User, 'id' | 'name' | 'email' | 'avatar'>;  // BUG: 'avatar' doesn't exist on User

export function toUserSummary(user: User): UserSummary {
    return {
        id: user.id,
        name: user.name,
        email: user.email,
        // BUG: avatar doesn't exist on User directly
        avatar: user.profile?.avatar
    };
}
