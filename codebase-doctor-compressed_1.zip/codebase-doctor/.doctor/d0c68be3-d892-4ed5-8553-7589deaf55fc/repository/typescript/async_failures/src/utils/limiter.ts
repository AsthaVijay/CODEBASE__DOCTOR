/**
 * Concurrency limiter for controlling parallel execution
 */

interface QueuedTask<T> {
  fn: () => Promise<T>;
  resolve: (value: T) => void;
  reject: (error: Error) => void;
}

export class ConcurrencyLimiter {
  private maxConcurrent: number;
  private running: number = 0;
  private queue: QueuedTask<unknown>[] = [];
  
  // BUG: Shared mutable state without proper synchronization
  private results: Map<string, unknown> = new Map();
  
  constructor(maxConcurrent: number = 3) {
    this.maxConcurrent = maxConcurrent;
  }
  
  /**
   * Execute a task with concurrency limiting
   * BUG: Race condition in checking/updating running count
   */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    // BUG: Check and increment are not atomic
    // Another task could increment between check and this increment
    if (this.running < this.maxConcurrent) {
      this.running++;
      return this.runTask(fn);
    }
    
    // Queue the task for later
    return new Promise<T>((resolve, reject) => {
      this.queue.push({
        fn: fn as () => Promise<unknown>,
        resolve: resolve as (value: unknown) => void,
        reject
      });
    });
  }
  
  /**
   * Run a task and process queue when done
   * BUG: Missing await causes premature queue processing
   */
  private async runTask<T>(fn: () => Promise<T>): Promise<T> {
    try {
      const result = await fn();
      return result;
    } finally {
      this.running--;
      // BUG: Not awaiting processQueue - runs in background
      this.processQueue();
    }
  }
  
  /**
   * Process next item in queue
   * BUG: Race condition when multiple tasks complete simultaneously
   */
  private processQueue(): void {
    // BUG: Multiple calls can dequeue the same item due to async timing
    if (this.queue.length > 0 && this.running < this.maxConcurrent) {
      const task = this.queue.shift()!;
      this.running++;
      
      // BUG: Fire and forget - errors not properly propagated
      this.runTask(task.fn)
        .then(task.resolve)
        .catch(task.reject);
    }
  }
  
  /**
   * Execute all tasks with concurrency limit
   * BUG: Results can be out of order, corrupting index mapping
   */
  async executeAll<T>(tasks: Array<() => Promise<T>>): Promise<T[]> {
    const results: T[] = [];
    
    // BUG: Race condition - results array modified concurrently
    // Results may not align with original task order
    const promises = tasks.map(async (task, index) => {
      const result = await this.execute(task);
      // BUG: Index-based assignment with concurrent modification
      results[index] = result;
    });
    
    // BUG: If one task fails, others still running are orphaned
    await Promise.all(promises);
    
    return results;
  }
  
  /**
   * Store result with key
   * BUG: Not atomic - can lose updates under contention
   */
  async storeResult(key: string, value: unknown): Promise<void> {
    // BUG: Read-modify-write without locking
    // Simulated async operation that creates race window
    const current = this.results.get(key);
    
    // Artificial delay to expose race condition
    await new Promise(resolve => setTimeout(resolve, 1));
    
    if (current !== undefined) {
      // BUG: Merge logic can lose concurrent updates
      this.results.set(key, { ...current as object, ...value as object });
    } else {
      this.results.set(key, value);
    }
  }
  
  /**
   * Get current running count (for debugging)
   */
  getRunningCount(): number {
    return this.running;
  }
  
  /**
   * Get queue length (for debugging)
   */
  getQueueLength(): number {
    return this.queue.length;
  }
}

/**
 * Semaphore for limiting concurrent access
 * BUG: acquire/release not properly balanced
 */
export class Semaphore {
  private permits: number;
  private waiting: Array<() => void> = [];
  
  constructor(permits: number) {
    this.permits = permits;
  }
  
  /**
   * Acquire a permit
   * BUG: Can deadlock if release is not called
   */
  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return;
    }
    
    // Wait for a permit
    return new Promise(resolve => {
      this.waiting.push(resolve);
    });
  }
  
  /**
   * Release a permit
   * BUG: Can be called more times than acquire, corrupting count
   */
  release(): void {
    if (this.waiting.length > 0) {
      const next = this.waiting.shift()!;
      // BUG: Should increment permits if no waiters
      // BUG: Calling next() synchronously can cause stack overflow with many waiters
      next();
    } else {
      this.permits++;
    }
  }
  
  /**
   * Execute with automatic acquire/release
   * BUG: Release not called if fn throws before await
   */
  async withPermit<T>(fn: () => Promise<T>): Promise<T> {
    await this.acquire();
    // BUG: If fn() throws synchronously, release is never called
    const result = await fn();
    this.release();
    return result;
  }
}
