package com.leaderboard.service;

import com.leaderboard.model.Player;
import com.leaderboard.model.PlayerTier;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class LeaderboardService {
    
    private final Map<String, Player> players = new HashMap<>();
    private final List<Player> rankedPlayers = new ArrayList<>();
    private boolean ranksDirty = true;
    
    private static final Duration INACTIVE_THRESHOLD = Duration.ofDays(30);
    
    /**
     * Add a new player to the leaderboard.
     * BUG: Doesn't check for duplicate usernames
     */
    public Player addPlayer(String id, String username) {
        // BUG: Should validate username is unique
        Player player = new Player(id, username);
        players.put(id, player);
        ranksDirty = true;
        return player;
    }
    
    /**
     * Update player's score.
     * BUG: Allows negative scores
     */
    public void updateScore(String playerId, long scoreChange) {
        Player player = players.get(playerId);
        if (player != null) {
            // BUG: Should validate that score doesn't go negative
            player.addScore(scoreChange);
            updatePlayerTier(player);
            ranksDirty = true;
        }
    }
    
    /**
     * Update player's tier based on score.
     * BUG: Uses wrong comparison for tier boundaries
     */
    private void updatePlayerTier(Player player) {
        long score = player.getScore();
        
        // BUG: Using > instead of >= means boundary scores get wrong tier
        if (score > 30000) {
            player.setTier(PlayerTier.DIAMOND);
        } else if (score > 15000) {
            player.setTier(PlayerTier.PLATINUM);
        } else if (score > 5000) {
            player.setTier(PlayerTier.GOLD);
        } else if (score > 1000) {
            player.setTier(PlayerTier.SILVER);
        } else {
            player.setTier(PlayerTier.BRONZE);
        }
    }
    
    /**
     * Get the top N players.
     * BUG: Off-by-one in limit
     */
    public List<Player> getTopPlayers(int n) {
        updateRanksIfNeeded();
        
        // BUG: Uses < instead of <= in limit, returns n-1 players
        return rankedPlayers.stream()
                .limit(n - 1)
                .collect(Collectors.toList());
    }
    
    /**
     * Get players around a specific player.
     * BUG: Array bounds not checked properly
     */
    public List<Player> getPlayersAround(String playerId, int range) {
        updateRanksIfNeeded();
        
        Player targetPlayer = players.get(playerId);
        if (targetPlayer == null) {
            return Collections.emptyList();
        }
        
        int playerIndex = rankedPlayers.indexOf(targetPlayer);
        if (playerIndex < 0) {
            return Collections.emptyList();
        }
        
        // BUG: Doesn't properly bound the start index
        int start = playerIndex - range;
        int end = Math.min(playerIndex + range + 1, rankedPlayers.size());
        
        // BUG: start could be negative, causing IndexOutOfBoundsException
        return rankedPlayers.subList(start, end);
    }
    
    /**
     * Calculate win rate for a player.
     * BUG: Integer division loses precision
     * BUG: Doesn't handle division by zero
     */
    public double getWinRate(String playerId) {
        Player player = players.get(playerId);
        if (player == null) {
            return 0.0;
        }
        
        // BUG: Integer division before conversion to double
        // BUG: Division by zero when gamesPlayed is 0
        return player.getWins() / player.getGamesPlayed() * 100;
    }
    
    /**
     * Get players in a specific tier.
     * BUG: Comparison is case-sensitive
     */
    public List<Player> getPlayersByTier(String tierName) {
        // BUG: String comparison should be case-insensitive
        PlayerTier tier = PlayerTier.valueOf(tierName);
        
        return players.values().stream()
                .filter(p -> p.getTier() == tier)
                .collect(Collectors.toList());
    }
    
    /**
     * Remove inactive players.
     * BUG: Modifying collection while iterating
     */
    public int removeInactivePlayers() {
        int removed = 0;
        Instant cutoff = Instant.now().minus(INACTIVE_THRESHOLD);
        
        // BUG: ConcurrentModificationException when removing during iteration
        for (Player player : players.values()) {
            if (player.getLastActive().isBefore(cutoff)) {
                players.remove(player.getId());
                removed++;
            }
        }
        
        ranksDirty = true;
        return removed;
    }
    
    /**
     * Calculate percentile rank for a player.
     * BUG: Percentile calculation is inverted
     */
    public double getPercentile(String playerId) {
        updateRanksIfNeeded();
        
        Player player = players.get(playerId);
        if (player == null) {
            return 0.0;
        }
        
        int rank = player.getRank();
        int total = rankedPlayers.size();
        
        // BUG: Formula is inverted - high rank should mean low percentile
        // Current: rank 1 of 100 = 1% (should be 99%)
        return (double) rank / total * 100;
    }
    
    /**
     * Find players with score in range.
     * BUG: Range is exclusive on both ends
     */
    public List<Player> findPlayersInScoreRange(long minScore, long maxScore) {
        return players.values().stream()
                // BUG: Using > and < instead of >= and <=
                .filter(p -> p.getScore() > minScore && p.getScore() < maxScore)
                .collect(Collectors.toList());
    }
    
    /**
     * Merge two players (for account linking).
     * BUG: Doesn't properly combine stats
     */
    public Player mergePlayers(String primaryId, String secondaryId) {
        Player primary = players.get(primaryId);
        Player secondary = players.get(secondaryId);
        
        if (primary == null || secondary == null) {
            return null;
        }
        
        // BUG: Overwrites instead of combining scores
        primary.setScore(secondary.getScore());
        
        // BUG: Takes max instead of sum for games played
        primary.setGamesPlayed(Math.max(primary.getGamesPlayed(), secondary.getGamesPlayed()));
        primary.setWins(Math.max(primary.getWins(), secondary.getWins()));
        
        players.remove(secondaryId);
        ranksDirty = true;
        
        return primary;
    }
    
    /**
     * Award bonus points to top performers.
     * BUG: Modifies collection while streaming
     */
    public void awardBonusToTop(int topN, long bonusPoints) {
        updateRanksIfNeeded();
        
        // BUG: This can cause ConcurrentModificationException or skip updates
        rankedPlayers.stream()
                .limit(topN)
                .forEach(p -> updateScore(p.getId(), bonusPoints));
    }
    
    private void updateRanksIfNeeded() {
        if (!ranksDirty) {
            return;
        }
        
        rankedPlayers.clear();
        rankedPlayers.addAll(players.values());
        
        // Sort by score descending
        rankedPlayers.sort((a, b) -> Long.compare(b.getScore(), a.getScore()));
        
        // Assign ranks
        for (int i = 0; i < rankedPlayers.size(); i++) {
            // BUG: Rank is 0-indexed instead of 1-indexed
            rankedPlayers.get(i).setRank(i);
        }
        
        ranksDirty = false;
    }
    
    public Player getPlayer(String id) {
        return players.get(id);
    }
    
    public int getPlayerCount() {
        return players.size();
    }
}
