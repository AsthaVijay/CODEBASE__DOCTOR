# Swift UI Thread - Image Gallery App

An iOS Image Gallery application demonstrating common main thread and UI threading bugs.

## Difficulty: ⭐⭐⭐

## Bug Categories

### Blocking Main Thread
- Synchronous network calls (`Data(contentsOf: url)`) on main thread
- `Thread.sleep()` in UI code
- Heavy image processing during scroll
- File I/O operations blocking UI

### UI Updates from Background Thread
- Setting `UILabel.text` from `DispatchQueue.global()`
- Updating `UIProgressView` from background
- Calling `reloadData()` off main thread
- Setting `UIImageView.image` from async callback

### Presentation from Background Thread
- `present()` UIAlertController from background
- Navigation controller `pushViewController()` off main
- UIView animations from background thread

### Race Conditions
- Array modification from multiple threads
- Dictionary access without synchronization
- `@Published` updates from background thread

### Callback Thread Issues
- Completion handlers called on background thread
- Delegate methods invoked off main thread
- Combine publishers missing `.receive(on: .main)`

## Expected Behavior

### What Should Happen
- UI remains responsive during network calls
- Smooth scrolling in collection view
- Progress updates appear smoothly
- Alerts present correctly
- No crashes from thread violations

### What Actually Happens
- UI freezes for 2+ seconds during load
- Scroll stuttering and jank
- "UI API called on background thread" warnings
- Occasional crashes from thread safety violations
- Purple runtime warnings in Xcode

## Build & Run

```bash
swift build
```

Or open in Xcode and run on iOS Simulator.

## Testing for Bugs

### Main Thread Blocking
1. Launch app - observe 2+ second freeze on load
2. Scroll quickly - observe stuttering
3. Tap image - observe freeze during processing

### Background Thread UI Updates
1. Enable Main Thread Checker in Xcode
2. Load images - observe purple warnings
3. Check console for "UI API called on background thread"

### Alert Presentation
1. Trigger network error
2. Observe crash or warning about background presentation

### Race Conditions
1. Rapidly scroll during image load
2. Observe potential array index crashes
3. Run with Thread Sanitizer enabled

## Key Files to Examine

1. **ImageGallery.swift** - All threading bugs
   - `ImageGalleryViewController` - Main thread blocking, background UI updates
   - `ImageService` - Callbacks on wrong thread
   - `ImageDetailViewController` - Heavy processing on main thread
   - `UploadManager` - Delegate calls from background
   - `DatabaseManager` - Thread safety issues
   - `ImageSearchViewModel` - Combine publisher threading

## Project Structure

```
UIThread/
├── Package.swift
├── UIThread/
│   └── ImageGallery.swift    # All buggy code
└── README.md
```

## Common Symptoms

| Issue | Symptom |
|-------|---------|
| Main thread block | UI freeze, beachball |
| Background UI update | Purple warning, crash |
| Race condition | Random crash, data corruption |
| Wrong thread callback | UI not updating, warnings |

## Debugging Tools

1. **Main Thread Checker** - Enable in Xcode scheme
2. **Thread Sanitizer** - Detects race conditions
3. **Time Profiler** - Find blocking operations
4. **System Trace** - Analyze thread activity

## Correct Patterns (Reference)

```swift
// Background processing with main thread UI update
DispatchQueue.global().async {
    let result = heavyProcessing()
    DispatchQueue.main.async {
        self.updateUI(with: result)
    }
}

// Combine with main thread delivery
publisher
    .receive(on: DispatchQueue.main)
    .sink { ... }

// Thread-safe property access
private let queue = DispatchQueue(label: "com.app.cache")
func getCache() -> [String: Any] {
    queue.sync { cache }
}
```
