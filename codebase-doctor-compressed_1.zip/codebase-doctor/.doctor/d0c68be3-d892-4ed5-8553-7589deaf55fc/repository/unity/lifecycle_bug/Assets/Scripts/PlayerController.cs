using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RPGGame
{
    /// <summary>
    /// Player Controller with Unity lifecycle bugs
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        public float moveSpeed = 5f;
        public float jumpForce = 10f;
        
        [Header("References")]
        public Transform cameraTransform;
        public Animator animator;
        public AudioSource footstepAudio;
        
        private Rigidbody rb;
        private CharacterStats stats;
        private InventoryManager inventory;
        private bool isGrounded;
        
        // BUG: Awake vs Start ordering issue
        // Other scripts might depend on this being initialized in Awake
        void Start()
        {
            rb = GetComponent<Rigidbody>();
            stats = GetComponent<CharacterStats>();
            
            // BUG: FindObjectOfType in Start - might find wrong object or null
            inventory = FindObjectOfType<InventoryManager>();
            
            // BUG: Accessing singleton before it's initialized
            GameManager.Instance.RegisterPlayer(this);
        }
        
        // BUG: Using Awake for things that should be in Start
        void Awake()
        {
            // BUG: Trying to access other GameObjects that might not exist yet
            cameraTransform = GameObject.Find("MainCamera").transform;
            
            // BUG: GetComponent on other object in Awake
            animator = transform.Find("Model").GetComponent<Animator>();
        }
        
        void Update()
        {
            HandleInput();
            
            // BUG: Physics in Update instead of FixedUpdate
            rb.AddForce(Vector3.down * 9.81f);
        }
        
        void FixedUpdate()
        {
            // BUG: Input.GetKeyDown in FixedUpdate - might miss input
            if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
            {
                Jump();
            }
        }
        
        // BUG: LateUpdate modifying physics
        void LateUpdate()
        {
            // BUG: Setting velocity in LateUpdate causes jitter
            if (rb.velocity.magnitude > 10f)
            {
                rb.velocity = rb.velocity.normalized * 10f;
            }
        }
        
        void HandleInput()
        {
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");
            
            Vector3 movement = new Vector3(horizontal, 0, vertical) * moveSpeed;
            
            // BUG: Using Transform.Translate with Rigidbody - conflicts with physics
            transform.Translate(movement * Time.deltaTime);
        }
        
        void Jump()
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }
        
        // BUG: OnCollisionEnter without checking tag/layer properly
        void OnCollisionEnter(Collision collision)
        {
            // BUG: Comparing string with == instead of CompareTag
            if (collision.gameObject.tag == "Ground")
            {
                isGrounded = true;
            }
            
            // BUG: Accessing destroyed component
            var enemy = collision.gameObject.GetComponent<EnemyAI>();
            if (enemy != null)
            {
                enemy.TakeDamage(10);  // Enemy might be destroyed
            }
        }
        
        // BUG: OnDestroy cleanup issues
        void OnDestroy()
        {
            // BUG: GameManager might already be destroyed
            GameManager.Instance.UnregisterPlayer(this);
            
            // BUG: Not checking if coroutines are running
            // StopAllCoroutines();  // Missing
        }
        
        // BUG: OnDisable vs OnDestroy confusion
        void OnDisable()
        {
            // BUG: Stopping audio that might not exist
            footstepAudio.Stop();
            
            // BUG: Unsubscribing in OnDisable but subscribing in Start
            // This causes issues when object is temporarily disabled
            EventManager.OnGamePaused -= HandlePause;
        }
        
        void OnEnable()
        {
            // BUG: Subscription in OnEnable but component init in Start
            // First OnEnable happens before Start
            EventManager.OnGamePaused += HandlePause;
            
            // BUG: stats might not be initialized yet
            stats.ResetHealth();
        }
        
        void HandlePause(bool paused)
        {
            enabled = !paused;
        }
    }

    /// <summary>
    /// Character Stats with initialization order bugs
    /// </summary>
    public class CharacterStats : MonoBehaviour
    {
        public int maxHealth = 100;
        public int currentHealth;
        
        // BUG: Using field initializer that depends on maxHealth
        public float healthPercent = currentHealth / maxHealth;  // Always 0
        
        private UIManager uiManager;
        
        void Awake()
        {
            currentHealth = maxHealth;
        }
        
        void Start()
        {
            // BUG: FindObjectOfType might return null
            uiManager = FindObjectOfType<UIManager>();
            uiManager.UpdateHealthBar(healthPercent);  // NullReferenceException
        }
        
        public void TakeDamage(int damage)
        {
            currentHealth -= damage;
            
            // BUG: Division before null check
            float percent = (float)currentHealth / maxHealth;
            uiManager.UpdateHealthBar(percent);  // Might be null
            
            if (currentHealth <= 0)
            {
                Die();
            }
        }
        
        public void ResetHealth()
        {
            currentHealth = maxHealth;
        }
        
        void Die()
        {
            // BUG: Destroying object during physics callback
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Enemy AI with coroutine lifecycle bugs
    /// </summary>
    public class EnemyAI : MonoBehaviour
    {
        public Transform target;
        public float attackRange = 2f;
        
        private Coroutine attackRoutine;
        private bool isAttacking;
        
        void Start()
        {
            // BUG: Starting coroutine that references potentially null target
            attackRoutine = StartCoroutine(AttackLoop());
            
            // BUG: FindWithTag might return null
            target = GameObject.FindWithTag("Player").transform;
        }
        
        IEnumerator AttackLoop()
        {
            while (true)
            {
                // BUG: target might be destroyed
                float distance = Vector3.Distance(transform.position, target.position);
                
                if (distance < attackRange)
                {
                    Attack();
                }
                
                // BUG: Using WaitForSeconds in loop that should check for destruction
                yield return new WaitForSeconds(1f);
            }
        }
        
        void Attack()
        {
            // BUG: GetComponent on potentially destroyed object
            var playerStats = target.GetComponent<CharacterStats>();
            playerStats.TakeDamage(10);
        }
        
        public void TakeDamage(int damage)
        {
            // BUG: Not stopping coroutine before destroy
            Destroy(gameObject);
        }
        
        // BUG: OnDestroy doesn't clean up coroutines properly
        void OnDestroy()
        {
            // Missing: StopCoroutine(attackRoutine);
            // Missing: isAttacking = false;
        }
    }

    /// <summary>
    /// Game Manager Singleton with initialization bugs
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        // BUG: Singleton pattern without proper null handling
        public static GameManager Instance;
        
        private List<PlayerController> players = new List<PlayerController>();
        private bool isGamePaused;
        
        // BUG: Awake might be called after other scripts try to access Instance
        void Awake()
        {
            // BUG: No duplicate check
            Instance = this;
            
            // BUG: DontDestroyOnLoad without checking for duplicates
            DontDestroyOnLoad(gameObject);
        }
        
        void Start()
        {
            // BUG: Starting game logic in Start - other objects might not be ready
            StartGame();
        }
        
        void StartGame()
        {
            // BUG: Assuming players list is populated
            foreach (var player in players)
            {
                player.enabled = true;
            }
        }
        
        public void RegisterPlayer(PlayerController player)
        {
            players.Add(player);
        }
        
        public void UnregisterPlayer(PlayerController player)
        {
            // BUG: Modifying list that might be iterated
            players.Remove(player);
        }
        
        // BUG: OnApplicationQuit vs OnDestroy order
        void OnApplicationQuit()
        {
            // BUG: Setting Instance to null causes NullReference in other scripts' OnDestroy
            Instance = null;
        }
    }

    /// <summary>
    /// UI Manager with scene load lifecycle bugs
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        public static UIManager Instance;
        
        [SerializeField] private UnityEngine.UI.Slider healthBar;
        [SerializeField] private UnityEngine.UI.Text scoreText;
        
        void Awake()
        {
            Instance = this;
        }
        
        void OnEnable()
        {
            // BUG: Subscribing to scene load events without unsubscribing
            UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
        }
        
        // BUG: Missing OnDisable to unsubscribe
        
        void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        {
            // BUG: UI references might be invalid after scene load
            healthBar.value = 1f;
            scoreText.text = "0";
        }
        
        public void UpdateHealthBar(float percent)
        {
            // BUG: No null check for healthBar
            healthBar.value = percent;
        }
        
        public void UpdateScore(int score)
        {
            scoreText.text = score.ToString();
        }
    }

    /// <summary>
    /// Event Manager with delegate lifecycle bugs
    /// </summary>
    public static class EventManager
    {
        // BUG: Static events without proper cleanup
        public static event Action<bool> OnGamePaused;
        public static event Action<int> OnScoreChanged;
        public static event Action OnPlayerDied;
        
        // BUG: No way to clear events when changing scenes
        public static void TriggerGamePaused(bool paused)
        {
            // BUG: Not checking for null
            OnGamePaused(paused);  // NullReferenceException if no subscribers
        }
        
        public static void TriggerScoreChanged(int score)
        {
            OnScoreChanged?.Invoke(score);
        }
        
        // BUG: Clear method exists but is never called
        public static void ClearAllEvents()
        {
            OnGamePaused = null;
            OnScoreChanged = null;
            OnPlayerDied = null;
        }
    }

    /// <summary>
    /// Inventory Manager with instantiation lifecycle bugs
    /// </summary>
    public class InventoryManager : MonoBehaviour
    {
        public GameObject itemPrefab;
        private List<GameObject> items = new List<GameObject>();
        
        void Start()
        {
            // BUG: Instantiating in Start might conflict with other scripts
            for (int i = 0; i < 10; i++)
            {
                var item = Instantiate(itemPrefab);
                items.Add(item);
            }
        }
        
        public void AddItem(GameObject item)
        {
            // BUG: Adding item that might be destroyed
            items.Add(item);
        }
        
        public void RemoveItem(int index)
        {
            // BUG: Not destroying the GameObject, just removing from list
            items.RemoveAt(index);
        }
        
        void OnDestroy()
        {
            // BUG: Not cleaning up instantiated objects
            // foreach (var item in items) Destroy(item);  // Missing
        }
    }
}
