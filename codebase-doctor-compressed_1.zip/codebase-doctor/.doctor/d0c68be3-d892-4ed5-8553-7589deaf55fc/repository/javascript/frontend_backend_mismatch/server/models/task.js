// Task model - simulates database model
// BUG: Uses snake_case field names, frontend expects camelCase

// Ordered list of own fields with their defaults (undefined = required, no default)
const TASK_FIELDS = [
    ['task_id',     data => data.task_id || `task_${Date.now()}`],
    ['user_id',     data => data.user_id],
    ['title',       data => data.title],
    ['description', data => data.description || ''],
    ['status',      data => data.status || 'pending'],  // BUG: Uses 'pending', frontend expects 'todo'
    ['priority',    data => data.priority || 'medium'],
    ['due_date',    data => data.due_date || null],     // BUG: Stored as ISO string, sometimes sent as Unix
    ['created_at',  data => data.created_at || new Date().toISOString()],
    ['updated_at',  data => data.updated_at || new Date().toISOString()],
    ['tags',        data => data.tags || []],           // BUG: Stored as array, sometimes sent as comma-separated string
    ['assignee_id', data => data.assignee_id || null],  // BUG: Frontend expects 'assigneeId'
];

// Fields that update() accepts (excludes task_id, user_id, created_at)
const UPDATABLE_FIELDS = new Set([
    'title', 'description', 'status', 'priority',
    'due_date', 'tags', 'assignee_id'
]);

class Task {
    constructor(data) {
        for (const [field, defaultFn] of TASK_FIELDS) {
            this[field] = defaultFn(data);
        }
    }

    // BUG: toJSON returns snake_case, frontend expects camelCase
    toJSON() {
        const obj = {};
        for (const [field] of TASK_FIELDS) {
            obj[field] = this[field];
        }
        return obj;
    }

    // Status validation
    static validStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];
    // BUG: Frontend uses ['todo', 'inProgress', 'done', 'archived']

    static validPriorities = ['low', 'medium', 'high', 'urgent'];

    isValidStatus(status) {
        return Task.validStatuses.includes(status);
    }

    update(data) {
        for (const field of UPDATABLE_FIELDS) {
            if (data[field] !== undefined) this[field] = data[field];
        }
        this.updated_at = new Date().toISOString();
    }
}

// In-memory task store
const tasks = new Map();

// BUG: Pagination returns { tasks, total, page, limit }
// Frontend expects { data, totalCount, currentPage, pageSize }
const PAGINATION_DEFAULTS = { page: 1, limit: 10 };

const TaskStore = {
    create(taskData) {
        const task = new Task(taskData);
        tasks.set(task.task_id, task);
        return task;
    },

    findById(taskId) {
        return tasks.get(taskId) || null;
    },

    findByUserId(userId, options = {}) {
        let filtered = Array.from(tasks.values()).filter(t => t.user_id === userId);

        // Apply filters
        const filterFields = ['status', 'priority'];
        for (const field of filterFields) {
            if (options[field]) {
                // BUG: Direct comparison, but frontend might send mapped status
                filtered = filtered.filter(t => t[field] === options[field]);
            }
        }

        // Sort
        if (options.sortBy) {
            const sortField = options.sortBy;
            const sortOrder = options.sortOrder === 'asc' ? 1 : -1;
            filtered.sort((a, b) => {
                if (a[sortField] < b[sortField]) return -1 * sortOrder;
                if (a[sortField] > b[sortField]) return 1 * sortOrder;
                return 0;
            });
        }

        const page  = options.page  || PAGINATION_DEFAULTS.page;
        const limit = options.limit || PAGINATION_DEFAULTS.limit;
        const start = (page - 1) * limit;
        const paginated = filtered.slice(start, start + limit);

        return {
            tasks: paginated.map(t => t.toJSON()),
            total: filtered.length,
            page,
            limit
        };
    },

    update(taskId, data) {
        const task = tasks.get(taskId);
        if (!task) return null;
        task.update(data);
        return task;
    },

    delete(taskId) {
        return tasks.delete(taskId);
    },

    // Seed some initial data
    seed(userId) {
        const sampleTasks = [
            { title: 'Review project proposal', description: 'Check the Q4 project proposal document', status: 'pending',     priority: 'high'   },
            { title: 'Update documentation',    description: 'Update API docs with new endpoints',    status: 'in_progress', priority: 'medium' },
            { title: 'Fix login bug',            description: 'Users reporting issues with OAuth',     status: 'pending',     priority: 'urgent' },
            { title: 'Team meeting notes',       description: 'Write up notes from standup',           status: 'completed',   priority: 'low'    }
        ];

        sampleTasks.forEach(data => {
            this.create({ ...data, user_id: userId });
        });
    }
};

module.exports = { Task, TaskStore };
