/**
 * Webhook Validation Middleware
 */

const REQUIRED_FIELDS = {
    github: ['event'],
    stripe: ['type', 'data'],
    slack: ['type']
};

function validateWebhook(provider) {
    return (req, res, next) => {
        const body = req.body;

        // BUG: body might be undefined if express.json() failed
        if (!body || typeof body !== 'object') {
            return res.status(400).json({ error: 'Invalid JSON body' });
        }

        const required = REQUIRED_FIELDS[provider];
        
        // BUG: required might be undefined for unknown provider
        const missing = required.filter(field => !(field in body));

        if (missing.length > 0) {
            return res.status(400).json({
                error: 'Missing required fields',
                missing
            });
        }

        // Add provider to request
        req.webhookProvider = provider;
        next();
    };
}

// BUG: Should also verify webhook signatures for security
// Currently accepts any request without signature verification

module.exports = {
    validateWebhook
};
