'use strict';
const assert = require('assert');
const { describe, it, before, after } = require('node:test');

// ---------------------------------------------------------------------------
// Minimal stub for '../javascript/frontend_backend_mismatch/server/routes/auth'
// We intercept require() via Module._resolveFilename trick-free approach:
// patch the module cache directly before loading auth.js.
// ---------------------------------------------------------------------------
const Module = require('module');
const path = require('path');
const originalLoad = Module._load;

let validateTokenImpl = () => null;

Module._load = function (request, parent, isMain) {
  // Resolve relative to the auth middleware file location
  const authMiddlewarePath = path.resolve(
    __dirname,
    '../javascript/frontend_backend_mismatch/server/middleware'
  );
  if (
    request === '../routes/auth' &&
    parent &&
    parent.filename &&
    parent.filename.startsWith(authMiddlewarePath)
  ) {
    return { validateToken: (token) => validateTokenImpl(token) };
  }
  return originalLoad.apply(this, arguments);
};

const { authMiddleware, optionalAuth } = require(
  '../javascript/frontend_backend_mismatch/server/middleware/auth.js'
);

Module._load = originalLoad; // restore

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function makeReq(authHeader) {
  return { headers: { authorization: authHeader } };
}

function makeRes() {
  const res = {
    _status: null,
    _body: null,
    status(code) { this._status = code; return this; },
    json(body) { this._body = body; return this; },
  };
  return res;
}

// ---------------------------------------------------------------------------
// authMiddleware
// ---------------------------------------------------------------------------
describe('authMiddleware', () => {
  it('returns 401 when Authorization header is missing', () => {
    const req = makeReq(undefined);
    const res = makeRes();
    authMiddleware(req, res, () => { throw new Error('next() should not be called'); });
    assert.strictEqual(res._status, 401);
    assert.strictEqual(res._body.error, 'Authorization header required');
  });

  it('returns 401 when header does not start with Bearer ', () => {
    const req = makeReq('tok_123456789'); // frontend bug: missing Bearer prefix
    const res = makeRes();
    authMiddleware(req, res, () => { throw new Error('next() should not be called'); });
    assert.strictEqual(res._status, 401);
    assert.strictEqual(res._body.error, 'Invalid authorization format');
  });

  it('returns 401 when token is empty after Bearer prefix', () => {
    const req = makeReq('Bearer ');
    const res = makeRes();
    authMiddleware(req, res, () => { throw new Error('next() should not be called'); });
    assert.strictEqual(res._status, 401);
    assert.strictEqual(res._body.error, 'Token required');
  });

  it('returns 401 when token is invalid or expired', () => {
    validateTokenImpl = () => null;
    const req = makeReq('Bearer bad_token');
    const res = makeRes();
    authMiddleware(req, res, () => { throw new Error('next() should not be called'); });
    assert.strictEqual(res._status, 401);
    assert.strictEqual(res._body.error, 'Invalid or expired token');
  });

  it('calls next() and attaches user data when token is valid', () => {
    validateTokenImpl = () => ({ user_id: 'u1', email: 'a@b.com' });
    const req = makeReq('Bearer valid_token');
    const res = makeRes();
    let nextCalled = false;
    authMiddleware(req, res, () => { nextCalled = true; });
    assert.strictEqual(nextCalled, true);
    assert.strictEqual(req.user_id, 'u1');
    assert.strictEqual(req.userEmail, 'a@b.com');
  });
});

// ---------------------------------------------------------------------------
// optionalAuth
// ---------------------------------------------------------------------------
describe('optionalAuth', () => {
  it('calls next() without touching req when no header is present', () => {
    const req = makeReq(undefined);
    const res = makeRes();
    let nextCalled = false;
    optionalAuth(req, res, () => { nextCalled = true; });
    assert.strictEqual(nextCalled, true);
    assert.strictEqual(req.user_id, undefined);
  });

  it('attaches user data when a valid Bearer token is present', () => {
    validateTokenImpl = () => ({ user_id: 'u2', email: 'c@d.com' });
    const req = makeReq('Bearer valid_token');
    const res = makeRes();
    let nextCalled = false;
    optionalAuth(req, res, () => { nextCalled = true; });
    assert.strictEqual(nextCalled, true);
    assert.strictEqual(req.user_id, 'u2');
    assert.strictEqual(req.userEmail, 'c@d.com');
  });

  it('still calls next() when Bearer token is invalid', () => {
    validateTokenImpl = () => null;
    const req = makeReq('Bearer bad_token');
    const res = makeRes();
    let nextCalled = false;
    optionalAuth(req, res, () => { nextCalled = true; });
    assert.strictEqual(nextCalled, true);
    assert.strictEqual(req.user_id, undefined);
  });

  it('still calls next() when header has no Bearer prefix', () => {
    const req = makeReq('tok_direct');
    const res = makeRes();
    let nextCalled = false;
    optionalAuth(req, res, () => { nextCalled = true; });
    assert.strictEqual(nextCalled, true);
    assert.strictEqual(req.user_id, undefined);
  });
});
