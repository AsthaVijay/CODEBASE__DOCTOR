/**
 * User Type Definitions
 */

export interface User {
    id: number;
    name: string;
    email: string;  // Required
    role: UserRole;
    createdAt: Date;
    updatedAt: Date;
    profile?: UserProfile;
}

export interface UserProfile {
    avatar: string;
    bio: string;
    location?: string;
    website?: string;
}

export type UserRole = 'admin' | 'user' | 'guest';

// BUG: CreateUserInput should make some fields optional
// but email is required in User but optional here (mismatch)
export interface CreateUserInput {
    name: string;
    email?: string;  // BUG: Should be required to match User
    role?: UserRole;
    profile?: Partial<UserProfile>;
}

// BUG: UpdateUserInput extends wrong base - should be Partial<Omit<User, 'id' | 'createdAt'>>
export interface UpdateUserInput extends Partial<User> {
    // This allows setting id and createdAt which shouldn't be allowed
}

// BUG: UserResponse uses different property names than User
export interface UserResponse {
    user_id: number;     // BUG: Should be 'id'
    username: string;    // BUG: Should be 'name'  
    email: string;
    role: string;        // BUG: Should be UserRole type
    created_at: string;  // BUG: Should be Date (or needs transformation)
    updated_at: string;
}

// BUG: Function returns UserResponse but callers expect User
export function createDefaultUser(): UserResponse {
    return {
        user_id: 0,
        username: 'Guest',
        email: 'guest@example.com',
        role: 'guest',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
    };
}

// BUG: Type predicate is incorrect - checks 'id' but UserResponse has 'user_id'
export function isValidUser(obj: unknown): obj is User {
    return (
        typeof obj === 'object' &&
        obj !== null &&
        'id' in obj &&
        'name' in obj &&
        'email' in obj
    );
}
