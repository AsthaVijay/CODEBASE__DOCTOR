// API configuration for the controlled Codebase Doctor demo.
// This is an intentionally fake credential, never a live key.
const API_KEY = process.env.API_KEY;
const API_URL = process.env.API_URL || "https://api.example.com";

module.exports = { API_KEY, API_URL };
