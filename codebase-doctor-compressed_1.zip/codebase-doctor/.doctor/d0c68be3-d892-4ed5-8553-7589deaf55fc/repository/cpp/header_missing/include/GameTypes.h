// GameTypes.h - Core type definitions
// BUG: No include guard - will cause multiple definition errors

#include "Components.h"  // BUG: Circular dependency - Components.h includes this

// BUG: Using std::string without #include <string>
// BUG: Using std::vector without #include <vector>
// BUG: Using std::unique_ptr without #include <memory>

namespace Game {

// Forward declarations
class Entity;
class Component;
class Transform;  // BUG: Forward declared but full definition needed below

// BUG: Incomplete type used in value context
struct EntityData {
    std::string name;              // BUG: string not included
    std::vector<int> tags;         // BUG: vector not included
    Transform transform;           // BUG: Incomplete type - can't have value of forward declared class
    std::unique_ptr<Entity> owner; // BUG: memory not included
};

// BUG: Template with incomplete type
template<typename T>
class Container {
    std::vector<T> items;  // BUG: vector not included
public:
    void add(const T& item) { items.push_back(item); }
    T& get(size_t index) { return items[index]; }  // BUG: size_t not included (cstddef)
};

// BUG: Using type from another header that has circular dependency
using ComponentList = std::vector<Component*>;

// Enum used across files
enum class ComponentType {
    Transform,
    Physics,
    Render,
    Script
};

// BUG: Inline function uses types without includes
inline std::string getTypeName(ComponentType type) {
    switch (type) {
        case ComponentType::Transform: return "Transform";
        case ComponentType::Physics: return "Physics";
        case ComponentType::Render: return "Render";
        case ComponentType::Script: return "Script";
    }
    return "Unknown";
}

// BUG: Struct uses std::function without #include <functional>
struct Callback {
    std::function<void(Entity*)> onUpdate;
    std::function<void(Entity*, Entity*)> onCollision;
};

// BUG: Using std::map without #include <map>
using EntityMap = std::map<std::string, Entity*>;

// BUG: Template partial specialization requires full definition
template<>
class Container<std::string> {
    std::vector<std::string> strings;  // BUG: vector not included
public:
    void add(const std::string& s) { strings.push_back(s); }
};

} // namespace Game
