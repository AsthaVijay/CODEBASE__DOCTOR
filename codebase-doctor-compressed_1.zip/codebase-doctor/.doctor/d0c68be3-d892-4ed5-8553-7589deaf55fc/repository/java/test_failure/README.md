# Leaderboard System

A gaming leaderboard service with player ranking, tier progression, and statistics tracking.

## The Bug

The project compiles successfully but the test suite fails. Tests identify multiple logic bugs in `LeaderboardService`:

### Score and Tier Bugs
- **Tier boundary error**: Uses `>` instead of `>=`, so score of 1000 gets BRONZE instead of SILVER
- **Negative scores allowed**: No validation prevents scores from going negative

### Ranking Bugs
- **Off-by-one in getTopPlayers**: `limit(n - 1)` returns n-1 players instead of n
- **Zero-indexed ranks**: Players get rank 0, 1, 2 instead of 1, 2, 3
- **Bounds error in getPlayersAround**: Start index can be negative, causing IndexOutOfBoundsException

### Calculation Bugs
- **Integer division in win rate**: `wins / gamesPlayed * 100` does integer division, always returning 0
- **Division by zero**: Win rate calculation crashes when no games played
- **Inverted percentile**: Rank 1 of 100 returns 1% instead of 99%

### Range and Comparison Bugs
- **Exclusive range**: Score range uses `>` and `<` instead of `>=` and `<=`
- **Case-sensitive tier lookup**: `getPlayersByTier("silver")` throws exception

### Collection Bugs
- **ConcurrentModification**: Removing from map while iterating in `removeInactivePlayers`
- **Stream modification**: `awardBonusToTop` modifies collection during stream operation

### Merge Bugs
- **Score overwrite**: Merging players overwrites score instead of adding
- **Max instead of sum**: Games/wins use `Math.max()` instead of addition

## Symptoms

```bash
$ mvn test

[ERROR] Tests run: 13, Failures: 11, Errors: 2, Skipped: 0

testTierBoundaryExact: expected: <SILVER> but was: <BRONZE>
testNegativeScorePrevention: Score should never be negative
testGetTopPlayersCount: expected: <3> but was: <2>
testRankIsOneIndexed: expected: <1> but was: <0>
testGetPlayersAroundEdge: IndexOutOfBoundsException: fromIndex = -2
testWinRateCalculation: expected: <66.67> but was: <0.0>
testWinRateZeroGames: ArithmeticException: / by zero
testPercentileTopPlayer: expected percentile >= 99 but was: <1.0>
testScoreRangeInclusive: expected: <3> but was: <1>
testMergePlayersAddsScores: expected: <1500> but was: <500>
testTierLookupCaseInsensitive: IllegalArgumentException: No enum constant
```

## Expected Behavior

When tests pass:
```bash
$ mvn test

[INFO] Tests run: 13, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

## Project Structure

```
src/
├── main/java/com/leaderboard/
│   ├── model/
│   │   ├── Player.java
│   │   └── PlayerTier.java
│   └── service/
│       └── LeaderboardService.java
└── test/java/com/leaderboard/
    └── LeaderboardServiceTest.java
```

## Difficulty

⭐⭐ (Beginner-Intermediate) - Tests clearly identify failing assertions:
- Error messages point to specific expected vs actual values
- Each test isolates one bug
- Fix locations are in single service class

## What Makes This Realistic

Test-driven debugging is common in professional development:
- CI/CD pipelines run tests on every commit
- Failing tests must be fixed before merge
- Test names and assertions guide debugging
- Multiple related bugs often appear together
