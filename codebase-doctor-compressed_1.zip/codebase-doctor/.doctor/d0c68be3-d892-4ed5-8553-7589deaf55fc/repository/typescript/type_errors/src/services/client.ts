/**
 * HTTP Client
 */

import { ApiResponse, PaginatedResponse, ApiError } from '../models/response';

export interface RequestConfig {
    headers?: Record<string, string>;
    params?: Record<string, string | number>;
    timeout?: number;
}

export interface HttpClient {
    get<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>>;
    post<T, D>(url: string, data: D, config?: RequestConfig): Promise<ApiResponse<T>>;
    put<T, D>(url: string, data: D, config?: RequestConfig): Promise<ApiResponse<T>>;
    delete<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>>;
}

export class Client implements HttpClient {
    private baseUrl: string;
    private defaultHeaders: Record<string, string>;

    constructor(baseUrl: string, headers?: Record<string, string>) {
        this.baseUrl = baseUrl;
        // BUG: headers might be undefined, can't spread undefined
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            ...headers  // BUG: TypeScript allows this but runtime might fail
        };
    }

    // BUG: Return type doesn't match - returns unknown but declares T
    async get<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
        const response = await this.request('GET', url, undefined, config);
        // BUG: response.data is unknown, not T
        return response;
    }

    // BUG: Data type D is not used in return type relationship
    async post<T, D>(url: string, data: D, config?: RequestConfig): Promise<ApiResponse<T>> {
        return this.request('POST', url, data, config);
    }

    async put<T, D>(url: string, data: D, config?: RequestConfig): Promise<ApiResponse<T>> {
        return this.request('PUT', url, data, config);
    }

    async delete<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
        return this.request('DELETE', url, undefined, config);
    }

    // BUG: Private method returns ApiResponse<unknown> but callers expect ApiResponse<T>
    private async request<T>(
        method: string,
        url: string,
        data?: unknown,
        config?: RequestConfig
    ): Promise<ApiResponse<T>> {
        const fullUrl = `${this.baseUrl}${url}`;
        
        // BUG: params might contain numbers but URLSearchParams expects strings
        const queryParams = new URLSearchParams(config?.params as Record<string, string>);
        
        const headers = {
            ...this.defaultHeaders,
            ...config?.headers
        };

        const fetchConfig: RequestInit = {
            method,
            headers,
            // BUG: body should only be included for POST/PUT, not GET/DELETE
            body: data ? JSON.stringify(data) : undefined
        };

        try {
            const response = await fetch(
                `${fullUrl}${queryParams.toString() ? '?' + queryParams.toString() : ''}`,
                fetchConfig
            );

            const json = await response.json();

            if (!response.ok) {
                // BUG: json might not have error property
                return {
                    success: false,
                    data: null as unknown as T,  // BUG: null is not assignable to T
                    error: json.error
                };
            }

            // BUG: json.data might not match T
            return {
                success: true,
                data: json.data
            };
        } catch (err) {
            // BUG: err type is unknown in catch block, need to narrow
            return {
                success: false,
                data: null as unknown as T,
                error: {
                    code: 'NETWORK_ERROR',
                    message: err.message  // BUG: err.message doesn't exist on unknown
                }
            };
        }
    }

    // BUG: Generic doesn't propagate correctly through pagination
    async getPaginated<T>(
        url: string,
        page: number,
        pageSize: number
    ): Promise<PaginatedResponse<T>> {
        const response = await this.get<T>(url, {
            params: { page, pageSize }  // BUG: numbers not allowed in params
        });

        // BUG: Spreading ApiResponse to create PaginatedResponse loses type info
        return {
            ...response,
            meta: {
                page,
                pageSize,
                total: 0,  // BUG: Should come from response
                hasMore: false
            }
        };
    }
}

// BUG: Factory function return type is too narrow
export function createClient(baseUrl: string): HttpClient {
    return new Client(baseUrl);
}
