package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"
)

// URLShortener - A simple URL shortening service
// Contains various runtime panic bugs for debugging practice

type URL struct {
	Original    string    `json:"original"`
	Short       string    `json:"short"`
	CreatedAt   time.Time `json:"created_at"`
	AccessCount int       `json:"access_count"`
	ExpiresAt   *time.Time `json:"expires_at,omitempty"`
	Tags        []string  `json:"tags,omitempty"`
	Metadata    map[string]string `json:"metadata,omitempty"`
}

type URLStore struct {
	urls    map[string]*URL
	byShort map[string]*URL
	mu      sync.RWMutex
}

type Analytics struct {
	TotalURLs     int            `json:"total_urls"`
	TotalAccesses int            `json:"total_accesses"`
	TopURLs       []*URL         `json:"top_urls"`
	TagCounts     map[string]int `json:"tag_counts"`
}

var store *URLStore

func main() {
	// BUG: store is never initialized, will cause nil pointer panic
	// store = NewURLStore()

	http.HandleFunc("/shorten", handleShorten)
	http.HandleFunc("/r/", handleRedirect)
	http.HandleFunc("/stats", handleStats)
	http.HandleFunc("/analytics", handleAnalytics)
	http.HandleFunc("/bulk", handleBulkShorten)

	fmt.Println("URL Shortener running on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func NewURLStore() *URLStore {
	return &URLStore{
		urls:    make(map[string]*URL),
		byShort: make(map[string]*URL),
	}
}

// BUG: No nil check on store before accessing
func (s *URLStore) Add(url *URL) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.urls[url.Original] = url
	s.byShort[url.Short] = url
	return nil
}

func (s *URLStore) GetByShort(short string) *URL {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.byShort[short]
}

func (s *URLStore) GetAll() []*URL {
	s.mu.RLock()
	defer s.mu.RUnlock()

	result := make([]*URL, 0, len(s.urls))
	for _, url := range s.urls {
		result = append(result, url)
	}
	return result
}

func handleShorten(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		URL       string            `json:"url"`
		ExpiresIn string            `json:"expires_in,omitempty"`
		Tags      []string          `json:"tags,omitempty"`
		Metadata  map[string]string `json:"metadata,omitempty"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	url := &URL{
		Original:  req.URL,
		Short:     generateShortCode(req.URL),
		CreatedAt: time.Now(),
		Tags:      req.Tags,
		Metadata:  req.Metadata,
	}

	// BUG: Accessing potentially nil ExpiresAt pointer later
	if req.ExpiresIn != "" {
		duration, _ := time.ParseDuration(req.ExpiresIn)
		expires := time.Now().Add(duration)
		url.ExpiresAt = &expires
	}

	// BUG: store is nil - will panic here
	store.Add(url)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(url)
}

func handleRedirect(w http.ResponseWriter, r *http.Request) {
	short := strings.TrimPrefix(r.URL.Path, "/r/")
	
	// BUG: store is nil - will panic
	url := store.GetByShort(short)

	// BUG: No nil check before accessing url fields
	// If URL not found, url is nil and this will panic
	url.AccessCount++

	// BUG: Dereferencing potentially nil ExpiresAt
	if url.ExpiresAt != nil && time.Now().After(*url.ExpiresAt) {
		http.Error(w, "URL expired", http.StatusGone)
		return
	}

	http.Redirect(w, r, url.Original, http.StatusFound)
}

func handleStats(w http.ResponseWriter, r *http.Request) {
	short := r.URL.Query().Get("short")
	
	// BUG: store is nil
	url := store.GetByShort(short)
	
	// BUG: No nil check - panics if URL not found
	stats := map[string]interface{}{
		"original":     url.Original,
		"short":        url.Short,
		"access_count": url.AccessCount,
		"created_at":   url.CreatedAt,
		// BUG: Tags could be nil
		"tag_count":    len(url.Tags),
		// BUG: First tag access without checking length
		"primary_tag":  url.Tags[0],
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(stats)
}

func handleAnalytics(w http.ResponseWriter, r *http.Request) {
	// BUG: store is nil
	allURLs := store.GetAll()

	analytics := Analytics{
		TotalURLs: len(allURLs),
		TagCounts: make(map[string]int),
	}

	// Calculate total accesses
	for _, url := range allURLs {
		analytics.TotalAccesses += url.AccessCount
	}

	// Get top 5 URLs by access count
	// BUG: Doesn't sort, just takes first 5
	// BUG: Index out of bounds if less than 5 URLs
	analytics.TopURLs = allURLs[0:5]

	// Count tags
	for _, url := range allURLs {
		// BUG: url.Tags could be nil, ranging over nil slice is safe
		// but accessing individual elements elsewhere might not be
		for _, tag := range url.Tags {
			analytics.TagCounts[tag]++
		}
	}

	// BUG: Accessing metadata without nil check
	for _, url := range allURLs {
		if url.Metadata["featured"] == "true" {
			// Do something with featured URLs
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(analytics)
}

func handleBulkShorten(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		URLs []string `json:"urls"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	results := make([]*URL, len(req.URLs))

	for i, originalURL := range req.URLs {
		url := &URL{
			Original:  originalURL,
			Short:     generateShortCode(originalURL),
			CreatedAt: time.Now(),
		}
		// BUG: store is nil
		store.Add(url)
		results[i] = url
	}

	// BUG: Accessing first and last element without checking length
	summary := map[string]interface{}{
		"count":      len(results),
		"first_url":  results[0].Short,
		"last_url":   results[len(results)-1].Short,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(summary)
}

func generateShortCode(url string) string {
	// Simple hash-based short code
	hash := 0
	for _, c := range url {
		hash = hash*31 + int(c)
	}
	if hash < 0 {
		hash = -hash
	}
	
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, 6)
	for i := range result {
		result[i] = charset[hash%len(charset)]
		hash /= len(charset)
	}
	return string(result)
}
