/**
 * Request Logging Middleware
 */

function logRequest(req, res, next) {
    const start = Date.now();
    
    // Log request
    console.log(`--> ${req.method} ${req.path}`);
    
    // BUG: Modifying res.send without proper binding
    const originalSend = res.send;
    res.send = function(body) {
        const duration = Date.now() - start;
        // BUG: statusCode might not be set yet
        console.log(`<-- ${req.method} ${req.path} ${res.statusCode} (${duration}ms)`);
        // BUG: 'this' context might be wrong
        originalSend.call(this, body);
    };

    next();
}

module.exports = {
    logRequest
};
