/**
 * Slack Webhook Handler
 */
const notifier = require('../utils/notifier');

async function process(payload) {
    const eventType = payload.type;

    // Slack URL verification challenge
    if (eventType === 'url_verification') {
        return { challenge: payload.challenge };
    }

    // BUG: event might be undefined for some payload types
    const event = payload.event;

    switch (event.type) {
        case 'message':
            return handleMessage(event);
        case 'app_mention':
            return handleMention(event);
        case 'reaction_added':
            return handleReaction(event);
        default:
            console.log(`Unhandled Slack event: ${event.type}`);
            // BUG: Not returning anything - caller expects a return value
    }
}

async function handleMessage(event) {
    // BUG: event.text might be undefined for non-text messages (files, etc.)
    const text = event.text.toLowerCase();
    const channel = event.channel;
    const user = event.user;

    // BUG: bot_id check - event.bot_id might not exist, should check event.subtype
    if (event.bot_id) {
        return { eventType: 'message', skipped: 'bot' };
    }

    // Check for keywords
    const keywords = ['urgent', 'help', 'emergency', 'critical'];
    // BUG: .some() might fail if text is undefined
    const hasKeyword = keywords.some(kw => text.includes(kw));

    if (hasKeyword) {
        // BUG: Missing await on async function
        notifier.send('urgent-slack', {
            channel,
            user,
            message: event.text
        });
    }

    return { eventType: 'message', channel, user };
}

async function handleMention(event) {
    const text = event.text;
    const channel = event.channel;
    
    // BUG: Trying to split and access without null checks
    // event.text format: "<@BOTID> command args"
    const parts = text.split(' ');
    const command = parts[1];
    const args = parts.slice(2);

    // BUG: command might be undefined if mention had no text after bot ID
    console.log(`Bot mentioned with command: ${command}`);

    // Process commands
    // BUG: args.join() on potentially undefined
    const response = await processCommand(command, args.join(' '));
    
    return { eventType: 'app_mention', command, response };
}

async function processCommand(command, argsText) {
    // BUG: command might be undefined
    switch (command.toLowerCase()) {
        case 'status':
            return { action: 'status', result: 'All systems operational' };
        case 'help':
            return { action: 'help', result: 'Available commands: status, help, report' };
        case 'report':
            // BUG: Assuming argsText can be parsed as JSON
            const reportData = JSON.parse(argsText);
            return { action: 'report', data: reportData };
        default:
            return { action: 'unknown', command };
    }
}

async function handleReaction(event) {
    const reaction = event.reaction;
    const user = event.user;
    
    // BUG: item might have different structure based on item_type
    const itemType = event.item.type;
    const itemChannel = event.item.channel;
    const itemTs = event.item.ts;

    // Special reactions trigger notifications
    const alertReactions = ['rotating_light', 'fire', 'warning', 'sos'];
    
    if (alertReactions.includes(reaction)) {
        // BUG: Missing await
        notifier.send('reaction-alert', {
            reaction,
            user,
            // BUG: Constructing URL without validating item properties
            messageUrl: `https://slack.com/archives/${itemChannel}/p${itemTs.replace('.', '')}`
        });
    }

    return { eventType: 'reaction_added', reaction };
}

module.exports = {
    process
};
