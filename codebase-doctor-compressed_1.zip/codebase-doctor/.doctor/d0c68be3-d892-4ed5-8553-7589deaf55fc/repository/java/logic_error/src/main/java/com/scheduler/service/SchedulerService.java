package com.scheduler.service;

import com.scheduler.model.*;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class SchedulerService {
    
    private static final LocalTime WORK_DAY_START = LocalTime.of(9, 0);
    private static final LocalTime WORK_DAY_END = LocalTime.of(17, 0);
    private static final Duration MIN_MEETING_GAP = Duration.ofMinutes(15);
    
    private final Map<String, List<Meeting>> userMeetings = new HashMap<>();
    private final Map<String, List<TimeSlot>> userAvailability = new HashMap<>();
    
    /**
     * Find available time slots for all participants.
     * BUG: Doesn't properly handle timezone differences
     * BUG: Loop bounds are wrong - skips first or last day
     */
    public List<TimeSlot> findAvailableSlots(List<String> participants, 
                                              LocalDate startDate, 
                                              LocalDate endDate,
                                              Duration meetingDuration) {
        List<TimeSlot> availableSlots = new ArrayList<>();
        
        // BUG: Using < instead of <= means endDate is excluded
        for (LocalDate date = startDate; date.isBefore(endDate); date = date.plusDays(1)) {
            // Skip weekends
            if (isWeekend(date)) {
                continue;
            }
            
            List<TimeSlot> daySlots = findAvailableSlotsForDay(participants, date, meetingDuration);
            availableSlots.addAll(daySlots);
        }
        
        return availableSlots;
    }
    
    /**
     * Check if a date is a weekend.
     * BUG: Saturday check is wrong
     */
    private boolean isWeekend(LocalDate date) {
        DayOfWeek day = date.getDayOfWeek();
        // BUG: Uses == instead of equals, and SATURDAY check has wrong value comparison
        return day.getValue() == 6 || day.getValue() == 7;  // Actually correct, but inconsistent
    }
    
    /**
     * Find available slots for a specific day.
     * BUG: Off-by-one in slot generation
     */
    private List<TimeSlot> findAvailableSlotsForDay(List<String> participants,
                                                     LocalDate date,
                                                     Duration meetingDuration) {
        List<TimeSlot> freeSlots = new ArrayList<>();
        
        LocalDateTime dayStart = LocalDateTime.of(date, WORK_DAY_START);
        LocalDateTime dayEnd = LocalDateTime.of(date, WORK_DAY_END);
        
        // Get all meetings for all participants
        List<Meeting> allMeetings = participants.stream()
                .flatMap(p -> getMeetingsForUser(p).stream())
                .filter(m -> m.getTimeSlot().getStart().toLocalDate().equals(date))
                .sorted(Comparator.comparing(m -> m.getTimeSlot().getStart()))
                .collect(Collectors.toList());
        
        LocalDateTime slotStart = dayStart;
        
        for (Meeting meeting : allMeetings) {
            LocalDateTime meetingStart = meeting.getTimeSlot().getStart();
            LocalDateTime meetingEnd = meeting.getTimeSlot().getEnd();
            
            // Check if there's a gap before this meeting
            if (slotStart.isBefore(meetingStart)) {
                TimeSlot potentialSlot = new TimeSlot(slotStart, meetingStart);
                
                // BUG: canFit uses > instead of >= so exact-fit slots are rejected
                if (potentialSlot.canFit(meetingDuration)) {
                    // Add buffer time
                    LocalDateTime adjustedEnd = meetingStart.minus(MIN_MEETING_GAP);
                    if (slotStart.plus(meetingDuration).isBefore(adjustedEnd)) {
                        freeSlots.add(new TimeSlot(slotStart, adjustedEnd));
                    }
                }
            }
            
            // BUG: Doesn't add the gap duration, just uses meeting end
            slotStart = meetingEnd;
        }
        
        // Check for slot after last meeting
        if (slotStart.isBefore(dayEnd)) {
            TimeSlot lastSlot = new TimeSlot(slotStart, dayEnd);
            if (lastSlot.canFit(meetingDuration)) {
                freeSlots.add(lastSlot);
            }
        }
        
        return freeSlots;
    }
    
    /**
     * Schedule a meeting with conflict detection.
     * BUG: Race condition - doesn't lock during check-and-schedule
     * BUG: Overlap detection is inverted
     */
    public boolean scheduleMeeting(Meeting meeting) {
        List<String> allParticipants = new ArrayList<>(meeting.getAttendees());
        allParticipants.add(meeting.getOrganizer());
        
        // Check for conflicts
        for (String participant : allParticipants) {
            List<Meeting> existingMeetings = getMeetingsForUser(participant);
            
            for (Meeting existing : existingMeetings) {
                // BUG: overlaps() method has inverted logic
                if (meeting.getTimeSlot().overlaps(existing.getTimeSlot())) {
                    // Should return false, but overlaps() is buggy
                    return false;
                }
            }
        }
        
        // Add meeting to all participants
        for (String participant : allParticipants) {
            userMeetings.computeIfAbsent(participant, k -> new ArrayList<>()).add(meeting);
        }
        
        return true;
    }
    
    /**
     * Reschedule a meeting to a new time.
     * BUG: Doesn't remove old meeting before checking conflicts
     */
    public boolean rescheduleMeeting(String meetingId, TimeSlot newTimeSlot) {
        Meeting meeting = findMeetingById(meetingId);
        if (meeting == null) {
            return false;
        }
        
        // BUG: Creates a copy but the original is still in the lists
        // causing false conflict detection
        Meeting tempMeeting = new Meeting(meeting.getTitle(), meeting.getOrganizer(), newTimeSlot);
        tempMeeting.setAttendees(meeting.getAttendees());
        
        // This will fail because original meeting causes conflict
        if (!scheduleMeeting(tempMeeting)) {
            return false;
        }
        
        // Update original meeting
        meeting.setTimeSlot(newTimeSlot);
        meeting.setStatus(MeetingStatus.RESCHEDULED);
        
        return true;
    }
    
    /**
     * Calculate meeting room requirements based on attendee count.
     * BUG: Off-by-one in room size thresholds
     */
    public String suggestRoomSize(int attendeeCount) {
        // BUG: Boundaries are exclusive when they should be inclusive
        if (attendeeCount < 4) {
            return "Small Huddle Room (2-4 people)";
        } else if (attendeeCount < 8) {
            return "Medium Conference Room (5-8 people)";
        } else if (attendeeCount < 15) {
            return "Large Conference Room (9-15 people)";
        } else {
            return "Auditorium (15+ people)";
        }
        // BUG: Person with exactly 4 attendees gets "Small" but description says "2-4"
        // Person with exactly 8 gets "Medium" but description says "5-8"
    }
    
    /**
     * Calculate the optimal meeting time based on participant preferences.
     * BUG: Averaging times doesn't work correctly across day boundaries
     */
    public LocalTime suggestMeetingTime(List<LocalTime> preferredTimes) {
        if (preferredTimes.isEmpty()) {
            return LocalTime.of(10, 0); // Default
        }
        
        // BUG: Simple averaging of times doesn't account for wrap-around
        // e.g., 23:00 and 01:00 should average to midnight, not noon
        long totalMinutes = 0;
        for (LocalTime time : preferredTimes) {
            totalMinutes += time.toSecondOfDay() / 60;
        }
        
        // BUG: Integer division loses precision
        int averageMinutes = (int) (totalMinutes / preferredTimes.size());
        
        return LocalTime.of(averageMinutes / 60, averageMinutes % 60);
    }
    
    /**
     * Get meetings for a date range.
     * BUG: Comparison operators are inconsistent
     */
    public List<Meeting> getMeetingsInRange(String user, LocalDate start, LocalDate end) {
        return getMeetingsForUser(user).stream()
                .filter(m -> {
                    LocalDate meetingDate = m.getTimeSlot().getStart().toLocalDate();
                    // BUG: Uses isAfter for start (exclusive) but !isAfter for end (inclusive)
                    // This is inconsistent and confusing
                    return meetingDate.isAfter(start.minusDays(1)) && 
                           !meetingDate.isAfter(end);
                })
                .collect(Collectors.toList());
    }
    
    /**
     * Calculate meeting statistics.
     * BUG: Duration calculation doesn't handle DST transitions
     */
    public MeetingStats calculateStats(String user, LocalDate startDate, LocalDate endDate) {
        List<Meeting> meetings = getMeetingsInRange(user, startDate, endDate);
        
        long totalMinutes = 0;
        int meetingCount = meetings.size();
        
        for (Meeting meeting : meetings) {
            // BUG: ChronoUnit.MINUTES doesn't account for DST
            totalMinutes += ChronoUnit.MINUTES.between(
                meeting.getTimeSlot().getStart(),
                meeting.getTimeSlot().getEnd()
            );
        }
        
        // BUG: Division by zero if no meetings
        double averageMinutes = totalMinutes / meetingCount;
        
        // BUG: Days calculation is off by one
        long days = ChronoUnit.DAYS.between(startDate, endDate);
        double meetingsPerDay = (double) meetingCount / days;
        
        return new MeetingStats(meetingCount, totalMinutes, averageMinutes, meetingsPerDay);
    }
    
    private List<Meeting> getMeetingsForUser(String user) {
        return userMeetings.getOrDefault(user, new ArrayList<>());
    }
    
    private Meeting findMeetingById(String id) {
        return userMeetings.values().stream()
                .flatMap(List::stream)
                .filter(m -> m.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    public record MeetingStats(int count, long totalMinutes, double averageMinutes, double perDay) {}
}
