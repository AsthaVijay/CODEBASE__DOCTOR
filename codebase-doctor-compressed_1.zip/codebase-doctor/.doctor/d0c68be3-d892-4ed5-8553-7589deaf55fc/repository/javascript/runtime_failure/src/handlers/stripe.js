/**
 * Stripe Webhook Handler
 */
const { formatCurrency } = require('../utils/formatter');
const notifier = require('../utils/notifier');

async function process(payload) {
    const eventType = payload.type;
    const data = payload.data;

    switch (eventType) {
        case 'payment_intent.succeeded':
            return handlePaymentSuccess(data);
        case 'payment_intent.failed':
            return handlePaymentFailure(data);
        case 'customer.subscription.created':
            return handleNewSubscription(data);
        case 'invoice.payment_failed':
            return handleInvoiceFailure(data);
        default:
            return { type: eventType, handled: false };
    }
}

async function handlePaymentSuccess(data) {
    // BUG: data.object might be undefined
    const payment = data.object;
    
    // BUG: amount is in cents (integer), but formatCurrency expects dollars
    // Also: amount might be a string from some webhook sources
    const amount = payment.amount;
    const currency = payment.currency;
    
    // BUG: toFixed is called but amount might be string
    const formatted = formatCurrency(amount.toFixed(2), currency);
    
    console.log(`Payment succeeded: ${formatted}`);
    
    // BUG: Accessing nested metadata without null check
    const customerId = payment.metadata.customer_id;
    const orderId = payment.metadata.order_id;

    await notifier.send('payment-success', {
        amount: formatted,
        customer: customerId,
        order: orderId
    });

    return { type: 'payment_intent.succeeded', amount };
}

async function handlePaymentFailure(data) {
    const payment = data.object;
    
    // BUG: last_payment_error might be null
    const error = payment.last_payment_error;
    const code = error.code;
    const message = error.message;

    console.error(`Payment failed: ${code} - ${message}`);

    // BUG: charges.data might be empty array
    const chargeId = payment.charges.data[0].id;

    await notifier.send('payment-failed', {
        error: code,
        message,
        chargeId
    });

    return { type: 'payment_intent.failed', error: code };
}

async function handleNewSubscription(data) {
    const subscription = data.object;
    
    // BUG: items.data might be undefined or empty
    const plan = subscription.items.data[0].plan;
    
    // BUG: plan.amount is in cents, comparing with dollar value string
    if (plan.amount > '1000') {
        console.log('High-value subscription created');
    }

    // BUG: Assuming plan.nickname exists
    const planName = plan.nickname || plan.id;
    
    // BUG: current_period_end is Unix timestamp, treating as Date
    const endDate = new Date(subscription.current_period_end);
    
    return {
        type: 'customer.subscription.created',
        plan: planName,
        // BUG: endDate might be invalid if timestamp wasn't converted
        ends: endDate.toISOString()
    };
}

async function handleInvoiceFailure(data) {
    const invoice = data.object;
    
    // BUG: customer might be string ID, not object
    const customerEmail = invoice.customer.email;
    
    // BUG: lines.data might be empty
    const items = invoice.lines.data.map(line => ({
        description: line.description,
        amount: line.amount / 100
    }));

    // BUG: attempt_count might be undefined for first failure
    const attempts = invoice.attempt_count;
    
    if (attempts > 2) {
        await notifier.send('invoice-final-failure', {
            customer: customerEmail,
            items,
            amount: invoice.amount_due / 100
        });
    }

    return { type: 'invoice.payment_failed', attempts };
}

module.exports = {
    process
};
