// PacketHandler.h - Packet Processing System
// BUG: Include guard uses reserved identifier (starts with underscore + capital)
#ifndef _PACKET_HANDLER_H_
#define _PACKET_HANDLER_H_

#include "NetworkEngine.h"  // BUG: Circular dependency - NetworkEngine.h includes PacketHandler.h

// BUG: Missing #include <queue>
// BUG: Missing #include <chrono>
// BUG: Missing #include <optional>

namespace Network {

// BUG: Using type from NetworkEngine.h that may not be visible due to circular include
struct PacketMetadata {
    PacketHeader header;  // From NetworkEngine.h - may fail due to circular dependency
    std::chrono::steady_clock::time_point timestamp;  // BUG: needs <chrono>
    uint8_t retryCount;
    bool acknowledged;
};

class Packet {
public:
    Packet(PacketType type);  // PacketType from NetworkEngine.h
    Packet(const PacketHeader& header, std::vector<uint8_t> payload);
    
    PacketHeader& getHeader();
    const PacketHeader& getHeader() const;
    
    std::vector<uint8_t>& getPayload();
    const std::vector<uint8_t>& getPayload() const;
    
    // Serialization
    std::vector<uint8_t> toBytes() const;
    static std::optional<Packet> fromBytes(const std::vector<uint8_t>& data);  // BUG: needs <optional>
    
    // Validation
    bool isValid() const;
    uint32_t getChecksum() const;
    
private:
    PacketHeader header;
    std::vector<uint8_t> payload;
    mutable std::optional<uint32_t> cachedChecksum;  // BUG: needs <optional>
};

class PacketQueue {
public:
    PacketQueue(size_t maxSize = 1000);
    
    void push(Packet packet);
    std::optional<Packet> pop();  // BUG: needs <optional>
    std::optional<Packet> peek() const;
    
    bool empty() const;
    size_t size() const;
    void clear();
    
    // Priority queue operations
    void pushPriority(Packet packet, int priority);
    
private:
    std::queue<Packet> normalQueue;  // BUG: needs <queue>
    std::priority_queue<std::pair<int, Packet>> priorityQueue;  // BUG: needs <queue>
    size_t maxSize;
    std::mutex queueMutex;  // BUG: needs <mutex>
};

// BUG: Using types that depend on circular include resolution
class PacketHandler {
public:
    virtual ~PacketHandler() = default;
    
    virtual void handlePacket(ConnectionId sender, const Packet& packet) = 0;
    virtual PacketType getHandledType() const = 0;
    
    // Rate limiting
    void setRateLimit(std::chrono::milliseconds interval);  // BUG: needs <chrono>
    bool checkRateLimit(ConnectionId sender);
    
protected:
    std::map<ConnectionId, std::chrono::steady_clock::time_point> lastPacketTime;
    std::chrono::milliseconds rateLimit{100};
};

class ConnectHandler : public PacketHandler {
public:
    void handlePacket(ConnectionId sender, const Packet& packet) override;
    PacketType getHandledType() const override { return PacketType::CONNECT; }
    
    // Events
    using ConnectCallback = std::function<void(ConnectionId, const PlayerData&)>;
    void onConnect(ConnectCallback callback);
    
private:
    std::vector<ConnectCallback> callbacks;  // BUG: needs <functional> for std::function
};

class GameStateHandler : public PacketHandler {
public:
    void handlePacket(ConnectionId sender, const Packet& packet) override;
    PacketType getHandledType() const override { return PacketType::GAME_STATE; }
    
    void setStateManager(GameStateManager* manager);  // BUG: GameStateManager not defined
    
private:
    GameStateManager* stateManager = nullptr;
};

// Factory for creating handlers
class PacketHandlerFactory {
public:
    static std::unique_ptr<PacketHandler> createHandler(PacketType type);  // BUG: needs <memory>
    
    template<typename T>
    static void registerHandler() {
        // BUG: Implementation references types from incomplete headers
        creators[T::HandledType] = []() { return std::make_unique<T>(); };
    }
    
private:
    static std::map<PacketType, std::function<std::unique_ptr<PacketHandler>()>> creators;
};

}  // namespace Network

#endif  // _PACKET_HANDLER_H_
