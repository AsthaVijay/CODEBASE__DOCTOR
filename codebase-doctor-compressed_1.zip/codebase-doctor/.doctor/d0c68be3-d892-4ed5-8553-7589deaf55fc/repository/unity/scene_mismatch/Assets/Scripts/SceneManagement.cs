using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SceneManagement
{
    /// <summary>
    /// Game Manager with scene loading and reference bugs
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;
        
        [Header("Scene References")]
        // BUG: Scene references by index - fragile if build settings change
        public int mainMenuSceneIndex = 0;
        public int gameSceneIndex = 1;
        public int bossSceneIndex = 2;
        
        // BUG: Direct object references - these become null when scene changes
        public GameObject player;
        public Camera mainCamera;
        public Canvas uiCanvas;
        public AudioSource musicSource;
        
        [Header("Managers")]
        // BUG: Manager references from other scenes
        public UIManager uiManager;
        public AudioManager audioManager;
        public SaveManager saveManager;
        
        private int currentScore;
        private bool isGamePaused;
        
        void Awake()
        {
            // BUG: No singleton check - duplicates when scene reloads
            Instance = this;
            DontDestroyOnLoad(gameObject);
            
            // BUG: Finding objects in Awake - scene might not be loaded
            player = GameObject.FindWithTag("Player");
            mainCamera = Camera.main;
        }
        
        void Start()
        {
            // BUG: Subscribe without checking if scene is loaded
            SceneManager.sceneLoaded += OnSceneLoaded;
            SceneManager.sceneUnloaded += OnSceneUnloaded;
            
            // BUG: FindObjectOfType after DontDestroyOnLoad - might find wrong instance
            uiManager = FindObjectOfType<UIManager>();
            audioManager = FindObjectOfType<AudioManager>();
        }
        
        // BUG: OnSceneLoaded uses references from previous scene
        void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            Debug.Log($"Scene loaded: {scene.name}");
            
            // BUG: Old references still point to destroyed objects
            if (player != null)
            {
                player.transform.position = Vector3.zero;  // Might be null
            }
            
            // BUG: Immediately accessing new scene objects - might not be awake yet
            var newPlayer = GameObject.FindWithTag("Player");
            var playerHealth = newPlayer.GetComponent<Health>();  // NullReferenceException
            playerHealth.SetHealth(100);
        }
        
        void OnSceneUnloaded(Scene scene)
        {
            // BUG: Not cleaning up references to destroyed objects
            // player, uiManager, etc. are now invalid
            
            Debug.Log($"Scene unloaded: {scene.name}");
        }
        
        public void LoadMainMenu()
        {
            // BUG: Using scene index - might be wrong if build settings change
            SceneManager.LoadScene(mainMenuSceneIndex);
            
            // BUG: Code after LoadScene still runs with old references
            uiManager.HideGameUI();  // uiManager might be destroyed
            audioManager.PlayMenuMusic();  // audioManager might be null
        }
        
        public void LoadGameScene()
        {
            // BUG: Async load without proper callback handling
            StartCoroutine(LoadSceneAsync(gameSceneIndex));
            
            // BUG: This runs before scene is loaded
            InitializeGame();
        }
        
        IEnumerator LoadSceneAsync(int sceneIndex)
        {
            AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneIndex);
            
            while (!asyncLoad.isDone)
            {
                // BUG: Updating UI that might be destroyed
                uiManager.UpdateLoadingProgress(asyncLoad.progress);
                yield return null;
            }
            
            // BUG: Scene is loaded but Start hasn't run yet
            player = GameObject.FindWithTag("Player");
            player.GetComponent<PlayerController>().Initialize();  // Component not ready
        }
        
        void InitializeGame()
        {
            // BUG: Called before scene load completes
            currentScore = 0;
            isGamePaused = false;
            
            // BUG: Accessing objects from not-yet-loaded scene
            var spawnPoints = FindObjectsOfType<SpawnPoint>();
            foreach (var spawn in spawnPoints)
            {
                spawn.SpawnEnemy();  // spawnPoints is empty array
            }
        }
        
        public void LoadAdditiveScene(string sceneName)
        {
            // BUG: Additive load without tracking loaded scenes
            SceneManager.LoadScene(sceneName, LoadSceneMode.Additive);
            
            // BUG: Duplicate objects when loading additively
            // Same "Player" tag exists in multiple scenes
        }
        
        public void UnloadScene(string sceneName)
        {
            // BUG: No check if scene is loaded
            SceneManager.UnloadSceneAsync(sceneName);
            
            // BUG: Objects from that scene are now destroyed but references exist
        }
        
        void OnDestroy()
        {
            // BUG: Not unsubscribing from static events
            // SceneManager.sceneLoaded -= OnSceneLoaded;
            // SceneManager.sceneUnloaded -= OnSceneUnloaded;
        }
        
        void OnApplicationQuit()
        {
            // BUG: Setting Instance to null causes issues in other OnDestroy
            Instance = null;
        }
    }

    /// <summary>
    /// UI Manager with scene reference issues
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        public static UIManager Instance;
        
        [Header("UI Elements")]
        // BUG: These references break when scene changes
        public GameObject healthBar;
        public GameObject scoreText;
        public GameObject pauseMenu;
        public GameObject loadingScreen;
        
        [Header("Prefabs")]
        // BUG: Prefab reference becomes null if UIManager is from different scene
        public GameObject damagePopupPrefab;
        
        private List<GameObject> activePopups = new List<GameObject>();
        
        void Awake()
        {
            // BUG: Singleton without DontDestroyOnLoad
            Instance = this;
        }
        
        void Start()
        {
            // BUG: Caching references that will become invalid
            healthBar = GameObject.Find("HealthBar");
            scoreText = GameObject.Find("ScoreText");
        }
        
        public void UpdateLoadingProgress(float progress)
        {
            // BUG: loadingScreen might be destroyed
            if (loadingScreen != null)
            {
                loadingScreen.SetActive(true);
                // BUG: Child reference might be invalid
                loadingScreen.transform.Find("ProgressBar").localScale = 
                    new Vector3(progress, 1, 1);
            }
        }
        
        public void ShowDamagePopup(Vector3 worldPos, int damage)
        {
            // BUG: Instantiating prefab that might be null after scene change
            var popup = Instantiate(damagePopupPrefab, worldPos, Quaternion.identity);
            activePopups.Add(popup);
            
            // BUG: activePopups contains references to destroyed objects
        }
        
        public void HideGameUI()
        {
            // BUG: References might be null
            healthBar.SetActive(false);  // NullReferenceException
            scoreText.SetActive(false);
        }
        
        public void ClearPopups()
        {
            // BUG: Iterating over list that contains destroyed objects
            foreach (var popup in activePopups)
            {
                Destroy(popup);  // MissingReferenceException
            }
            activePopups.Clear();
        }
    }

    /// <summary>
    /// Audio Manager with cross-scene issues
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance;
        
        // BUG: AudioClip references from Resources - should use asset bundles
        public AudioClip menuMusic;
        public AudioClip gameMusic;
        public AudioClip bossMusic;
        
        private AudioSource musicSource;
        private Dictionary<string, AudioClip> soundEffects = new Dictionary<string, AudioClip>();
        
        void Awake()
        {
            // BUG: Another incomplete singleton
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            
            musicSource = GetComponent<AudioSource>();
        }
        
        void OnEnable()
        {
            SceneManager.sceneLoaded += HandleSceneLoaded;
        }
        
        // BUG: Missing OnDisable to unsubscribe
        
        void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // BUG: Hardcoded scene name checks - fragile
            if (scene.name == "MainMenu")
            {
                PlayMenuMusic();
            }
            else if (scene.name == "GameScene")
            {
                PlayGameMusic();
            }
            else if (scene.name.Contains("Boss"))  // BUG: String contains check
            {
                PlayBossMusic();
            }
        }
        
        public void PlayMenuMusic()
        {
            // BUG: menuMusic might be unloaded
            musicSource.clip = menuMusic;
            musicSource.Play();
        }
        
        public void PlayGameMusic()
        {
            musicSource.clip = gameMusic;
            musicSource.Play();
        }
        
        public void PlayBossMusic()
        {
            musicSource.clip = bossMusic;
            musicSource.Play();
        }
        
        public void PlaySoundEffect(string name)
        {
            // BUG: Sound effects dictionary doesn't persist between scenes
            if (soundEffects.TryGetValue(name, out var clip))
            {
                // BUG: Using PlayClipAtPoint creates object in current scene
                AudioSource.PlayClipAtPoint(clip, Camera.main.transform.position);
            }
        }
    }

    /// <summary>
    /// Player Controller with scene transition issues
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        [Header("References")]
        // BUG: Cross-scene object references
        public Transform checkpoint;
        public Camera playerCamera;
        public UIManager ui;
        
        private Vector3 spawnPosition;
        private bool isInitialized;
        
        void Awake()
        {
            // BUG: Storing position that might be wrong after scene load
            spawnPosition = transform.position;
        }
        
        void Start()
        {
            // BUG: Finding objects that might be from wrong scene
            checkpoint = GameObject.Find("Checkpoint")?.transform;
            playerCamera = Camera.main;
            ui = UIManager.Instance;  // Might be null or from different scene
        }
        
        public void Initialize()
        {
            // BUG: Called before Start runs
            if (!isInitialized)
            {
                // BUG: UI might not be ready
                ui.ShowDamagePopup(transform.position, 0);
            }
            isInitialized = true;
        }
        
        public void RespawnAtCheckpoint()
        {
            // BUG: Checkpoint might be from previous scene
            if (checkpoint != null)
            {
                transform.position = checkpoint.position;  // MissingReferenceException
            }
            else
            {
                transform.position = spawnPosition;  // spawnPosition from wrong scene
            }
        }
        
        void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("LevelEnd"))
            {
                // BUG: Directly loading scene - bypasses GameManager
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                // BUG: This player object is destroyed, but GameManager still references it
            }
        }
    }

    /// <summary>
    /// Spawn Point - scene-specific object
    /// </summary>
    public class SpawnPoint : MonoBehaviour
    {
        public GameObject enemyPrefab;
        
        // BUG: Reference set in inspector - invalid after scene reload
        public Transform patrolRoute;
        
        public void SpawnEnemy()
        {
            // BUG: enemyPrefab might be null if loaded from different scene context
            var enemy = Instantiate(enemyPrefab, transform.position, transform.rotation);
            
            // BUG: patrolRoute might be null or destroyed
            enemy.GetComponent<Enemy>().SetPatrolRoute(patrolRoute);
        }
    }

    /// <summary>
    /// Enemy - instantiated object with reference issues
    /// </summary>
    public class Enemy : MonoBehaviour
    {
        private Transform patrolRoute;
        private Transform player;
        
        void Start()
        {
            // BUG: FindWithTag might find player from wrong scene (additive)
            player = GameObject.FindWithTag("Player")?.transform;
        }
        
        public void SetPatrolRoute(Transform route)
        {
            patrolRoute = route;
        }
        
        void Update()
        {
            // BUG: player might be destroyed after scene change
            if (player != null)
            {
                // Chase player
            }
        }
    }

    /// <summary>
    /// Save Manager with scene state issues
    /// </summary>
    public class SaveManager : MonoBehaviour
    {
        // BUG: Static reference without cleanup
        private static Dictionary<string, object> sceneState = new Dictionary<string, object>();
        
        public void SaveSceneState()
        {
            Scene currentScene = SceneManager.GetActiveScene();
            
            // BUG: FindObjectsOfType finds DontDestroyOnLoad objects too
            var saveables = FindObjectsOfType<ISaveable>();
            
            foreach (var saveable in saveables)
            {
                // BUG: Key collision if same object type in multiple scenes
                string key = saveable.GetType().Name;
                sceneState[key] = saveable.GetSaveData();
            }
        }
        
        public void LoadSceneState()
        {
            // BUG: Objects might not exist in new scene
            var saveables = FindObjectsOfType<ISaveable>();
            
            foreach (var saveable in saveables)
            {
                string key = saveable.GetType().Name;
                if (sceneState.TryGetValue(key, out var data))
                {
                    saveable.LoadSaveData(data);
                }
            }
        }
    }

    public interface ISaveable
    {
        object GetSaveData();
        void LoadSaveData(object data);
    }

    public class Health : MonoBehaviour
    {
        public void SetHealth(int value) { }
    }
}
